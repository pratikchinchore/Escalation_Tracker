const express = require("express");
const cors = require("cors");
const db = require("./model");
const linkRoutes = require("./routes/linkRoutes");
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const updateRoutes = require("./routes/updateRoutes");
const updateAssetRoutes = require("./routes/updateAssetRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes")
const subdomainRoutes = require("./routes/subdomainRoutes")

const app = express();
app.use(cors());
app.use(express.json());

// Register routes
app.use("/api/links", linkRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use("/api/updates", updateRoutes);
app.use("/api/update-assets", updateAssetRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/subdomain", subdomainRoutes);


// Start server after DB sync
db.sequelize.sync({ alter: true }).then(() => {
  app.listen(5000, () => {
    console.log("Server started on http://192.168.16.253:5000");
  });
});


												
  
