const { User } = require("../model");
const bcrypt = require("bcrypt");
const { generateToken } = require("../utils/jwt");

exports.login = async (req, res) => {
//  console.log(req.body);

  const { username, password } = req.body;
  try {
    // Step 1: Find user by username
    const user = await User.findOne({ where: { empID: username } });
    if (!user) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    if (user.status !== "1") {
      return res.status(409).json({ message: "User is deleted or inactive" });
    }
    // Step 2: Compare password with hashed password in DB
    const isDefaultPassword = await bcrypt.compare("12345", user.password);
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid username or password" });
    }
    // Step 3: Generate JWT token
    const token = generateToken({
      id: user.userId,
      empID: user.empID,
      role: user.role,
      username: user.username,
    });

    // Step 4: Respond with token and user details
    return res.status(200).json({
      token,
      role: user.role,
      username: user.username,
      empID: user.empID,
      isDefaultPassword,
    });
  } catch (err) {
    console.error("Login error:", err);
    return res.status(500).json({ error: "Internal server error" });
  }
};
