const { User, LinksView, sequelize, ReportView } = require("../model");

exports.getLinkCounts = async (req, res) => {
  try {
    const results = await User.findAll({
      attributes: [
        "username",
        [
          sequelize.literal(`
            COALESCE(
              COUNT(DISTINCT CASE 
                WHEN \`LinksViews\`.\`Campaign_Type\` = 'CS' 
                AND MONTH(\`LinksViews\`.\`createdAt\`) = MONTH(CURRENT_DATE())
                AND YEAR(\`LinksViews\`.\`createdAt\`) = YEAR(CURRENT_DATE())
                THEN \`LinksViews\`.\`link\` 
              END), 
              0
            )
          `),
          "cs_links",
        ],
        [
          sequelize.literal(`
            COALESCE(
              COUNT(DISTINCT CASE 
                WHEN \`LinksViews\`.\`Campaign_Type\` = 'Survey' 
                AND MONTH(\`LinksViews\`.\`createdAt\`) = MONTH(CURRENT_DATE())
                AND YEAR(\`LinksViews\`.\`createdAt\`) = YEAR(CURRENT_DATE())
                THEN \`LinksViews\`.\`link\` 
              END), 
              0
            )
          `),
          "survay_links",
        ],
        [
          sequelize.literal(`
            COALESCE(
              COUNT(DISTINCT CASE 
                WHEN \`LinksViews\`.\`Campaign_Type\` = 'E-Blast' 
                AND MONTH(\`LinksViews\`.\`createdAt\`) = MONTH(CURRENT_DATE())
                AND YEAR(\`LinksViews\`.\`createdAt\`) = YEAR(CURRENT_DATE())
                THEN \`LinksViews\`.\`link\` 
              END), 
              0
            )
          `),
          "e_blast_links",
        ],
      ],
      include: [
        {
          model: LinksView,
          as: "LinksViews", // Ensure this matches your association alias
          attributes: [],
          required: false,
        },
      ],
      where: {
        role: "PHP-Developer",
        status: 1,
      },
      group: ["User.username"],
      order: [["username", "ASC"]],
      raw: true,
    });

    res.json(results);
  } catch (err) {
    console.error("Error fetching link counts:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// exports.getReportViewCounts = async (req, res) => {
//   try {
//     const data = await ReportView.findAll({
//       attributes: [
//         [sequelize.fn("DATE", sequelize.col("createdAt")), "date"],
//         "made_by",
//         [
//           sequelize.literal(`
//             CASE
//               WHEN link_type IN ('Primary Link', 'Additional Link') THEN 'New Link'
//               WHEN link_type = 'Client Update' THEN 'Client Update'
//               WHEN link_type = 'Internal Update' THEN 'Internal Update'
//               ELSE 'Other'
//             END
//           `),
//           "category",
//         ],
//         [sequelize.fn("COUNT", sequelize.col("link_type")), "count"],
//       ],
//       group: [
//         sequelize.fn("DATE", sequelize.col("createdAt")),
//         "made_by",
//         sequelize.literal(`
//           CASE
//             WHEN link_type IN ('Primary Link', 'Additional Link') THEN 'New Link'
//             WHEN link_type = 'Client Update' THEN 'Client Update'
//             WHEN link_type = 'Internal Update' THEN 'Internal Update'
//             ELSE 'Other'
//           END
//         `),
//       ],
//       raw: true,
//     });

//     res.json(data);
//   } catch (error) {
//     console.error("Error:", error);
//     res.status(500).json({ error: "Failed to fetch data" });
//   }
// };


exports.getReportViewCounts = async (req, res) => {
  try {
    const data = await ReportView.findAll({
      attributes: [
        [sequelize.fn("DATE", sequelize.col("createdAt")), "date"],
        "made_by",
        [
          sequelize.literal(`
            CASE
              WHEN link_type IN ('Primary Link', 'Additional Link') THEN 'New Link'
              WHEN link_type = 'Client Update' THEN 'Client Update'
              WHEN link_type = 'Internal Update' THEN 'Internal Update'
              ELSE 'Other'
            END
          `),
          "category",
        ],
        [
          sequelize.literal(`
            CASE
              WHEN Campaign_Type IN ('CS', 'E-Blast') THEN 'CS'
              WHEN Campaign_Type = 'Survey' THEN 'Survey'
              ELSE 'Other'
            END
          `),
          "campaign_group",
        ],
        [sequelize.fn("COUNT", sequelize.col("link_type")), "count"],
      ],
      group: [
        sequelize.fn("DATE", sequelize.col("createdAt")),
        "made_by",
        sequelize.literal(`
          CASE
            WHEN link_type IN ('Primary Link', 'Additional Link') THEN 'New Link'
            WHEN link_type = 'Client Update' THEN 'Client Update'
            WHEN link_type = 'Internal Update' THEN 'Internal Update'
            ELSE 'Other'
          END
        `),
        sequelize.literal(`
          CASE
            WHEN Campaign_Type IN ('CS', 'E-Blast') THEN 'CS'
            WHEN Campaign_Type = 'Survey' THEN 'Survey'
            ELSE 'Other'
          END
        `),
      ],
      raw: true,
    });

    res.json(data);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Failed to fetch data" });
  }
};



exports.getAllReportViewData = async (req, res) => {
  try {
    const data = await ReportView.findAll({
      raw: true,
    });

    res.status(200).json(data);
  } catch (error) {
    console.error("Error fetching all report view data:", error);
    res.status(500).json({ error: "Failed to fetch report view data" });
  }
};
