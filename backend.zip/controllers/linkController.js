const db = require("../model");
const Link = db.Link;
const Asset = db.Asset;
const { Sequelize } = require("sequelize");


exports.createLink = async (req, res) => {
  console.log("Received Data:", req.body);
  const { description, ...linkData } = req.body;
  const made_by = req.user?.username || "Unknown";
  const link_type = "Primary Link";

  try {
    // Step 1: Create main Link record
    const newLink = await Link.create({ ...linkData, description, made_by });
    // Step 2: Parse description into individual asset records
    if (description && description.trim() !== "") {
      const rows = description.trim().split("\n");
      const assetRecords = rows.map((row) => {
        const [asset, link] = row.split("\t");
        return {
          asset: asset?.trim(),
          link: link?.trim(),
          camp_id: newLink.id,
          link_type,
          made_by,
        };
      });

      // Step 3: Save all asset records
      await Asset.bulkCreate(assetRecords);
    }

    res.status(201).json({
      message: "Link and associated assets created successfully",
      data: newLink,
    });
  } catch (error) {
    console.error("Error creating link and assets:", error);
    res.status(500).json({
      message: "Failed to create link and assets",
      error: error.message,
    });
  }
};

exports.createAssets = async (req, res) => {
  const { pastedData, camp_id, link_type, made_by } = req.body;

  try {
    const rows = pastedData.trim().split("\n");
    const records = rows.map((row) => {
      const [asset, link] = row.split("\t");
      return {
        asset: asset?.trim(),
        link: link?.trim(),
        camp_id,
        link_type,
        made_by,
      };
    });

    const created = await Asset.bulkCreate(records);
    res.status(201).json({ message: "Assets saved", data: created });
  } catch (err) {
    console.error("Error:", err);
    res.status(500).json({ error: "Failed to save assets" });
  }
};

exports.getAllLinks = async (req, res) => {
  try {
    const links = await Link.findAll();
    res.status(200).json(links);
  } catch (error) {
    console.error("Error fetching links:", error);
    res
      .status(500)
      .json({ message: "Failed to fetch links", error: error.message });
  }
};

exports.getAssetsByCampaign = async (req, res) => {
  try {
    const { camp_id } = req.params;
    const assets = await db.Asset.findAll({ where: { camp_id } });
    res.status(200).json(assets);
  } catch (error) {
    console.error("Error fetching assets:", error);
    res.status(500).json({ message: "Failed to fetch assets" });
  }
};

exports.appendAdditionalLink = async (req, res) => {
  const { camp_id, additionalLink } = req.body;
  //console.log("Appending link:", req.body);

  const made_by = req.user?.username || "Unknown";
  //console.log(req.user);

  const link_type = "Additional Link";

  try {
    // Step 1: Parse the additionalLink string (tab-separated format)
    const rows = additionalLink.trim().split("\n");
    const assetRecords = [];
    const newLinesForDescription = [];

    for (let row of rows) {
      const [asset, link] = row.split("\t");

      if (asset && link) {
        assetRecords.push({
          camp_id,
          asset: asset.trim(),
          link: link.trim(),
          made_by,
          link_type,
        });

        newLinesForDescription.push(`${asset.trim()}\t${link.trim()}`);
      }
    }

    // Step 2: Bulk insert into Asset table
    await Asset.bulkCreate(assetRecords);

    // Step 3: Append to existing Link.description
    const existingLink = await Link.findByPk(camp_id);
    if (!existingLink) {
      return res.status(404).json({ message: "Link not found" });
    }

    const updatedDescription = existingLink.description
      ? `${existingLink.description.trim()}\n${newLinesForDescription.join(
          "\n"
        )}`
      : newLinesForDescription.join("\n");

    await existingLink.update({ description: updatedDescription });

    res.status(200).json({
      message: "Additional links appended successfully",
      assets: assetRecords,
      updatedDescription,
    });
  } catch (error) {
    console.error("Error appending additional links:", error);
    res.status(500).json({
      message: "Failed to append additional links",
      error: error.message,
    });
  }
};

exports.updateCampaignStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body; // Expected: "Done" or "Pending"

  try {
    const link = await Link.findByPk(id);

    if (!link) {
      return res.status(404).json({ message: "Campaign not found" });
    }

    link.testing_status = status;
    await link.save();

    res.status(200).json({
      message: `Campaign status updated to ${status}`,
      data: link,
    });
  } catch (error) {
    console.error("Error updating status:", error);
    res.status(500).json({ message: "Failed to update campaign status" });
  }
};

const sequelize = db.sequelize;

exports.checkDuplicateLinks = async (req, res) => {
  try {
    console.log("CHECK DUPLICATES CONTROLLER");

    const { links } = req.body;

    if (!Array.isArray(links) || links.length === 0) {
      return res.status(400).json({ message: "No links provided" });
    }

    // Fetch duplicates with extra info
    const results = await sequelize.query(
      `SELECT link, Campaign_Name, made_by 
       FROM links_view 
       WHERE link IN (:links)`,
      {
        replacements: { links },
        type: Sequelize.QueryTypes.SELECT,
      }
    );

    // Send duplicates with metadata
    return res.status(200).json({ duplicates: results });
  } catch (error) {
    console.error("Error checking duplicate links:", error);
    res.status(500).json({
      message: "Failed to check duplicates",
      error: error.message,
    });
  }
};


