// controllers/jsonController.js
const fs = require("fs");
const path = require("path");

// map "type" → json file path
const FILE_MAP = {
  master: path.join(__dirname, "..", "../frontend/public/clientCodes.json"),
  phantom: path.join(__dirname, "..", "../frontend/public/phantomOptions.json"),
};

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// --- CRUD ---
exports.getAll = (req, res) => {
  try {
    const type = req.params.type;
    const file = FILE_MAP[type];
    if (!file) return res.status(400).json({ error: "Invalid type" });
    res.json(readJson(file));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// controllers/jsonController.js
exports.create = (req, res) => {
  try {
    const { type } = req.params;
    const file = FILE_MAP[type];
    if (!file) return res.status(400).json({ error: "Invalid type" });

    const { label, value } = req.body;
    if (!label || !value) {
      return res.status(400).json({ error: "label & value required" });
    }

    // phantom.json is still a flat array, master.json is an object of arrays
    let data = readJson(file);

    if (type === "phantom") {
      const newItem = { id: Date.now(), label, value };
      data.push(newItem);
      writeJson(file, data);
      return res.status(201).json(newItem);
    }

    // master
    const { category } = req.body;
    if (!data[category]) data[category] = [];
    const newItem = { id: Date.now(), label, value };
    data[category].push(newItem);
    writeJson(file, data);
    res.status(201).json(newItem);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.update = (req, res) => {
  try {
    const type = req.params.type;
    const file = FILE_MAP[type];
    if (!file) return res.status(400).json({ error: "Invalid type" });

    const id = parseInt(req.params.id);
    const data = readJson(file);
    const index = data.findIndex((item) => item.id === id);
    if (index === -1) return res.status(404).json({ error: "Item not found" });

    const { label, value } = req.body;
    data[index] = { ...data[index], label, value };
    writeJson(file, data);
    res.json(data[index]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.remove = (req, res) => {
  try {
    const { type, cat, id } = req.params;
    const file = FILE_MAP[type];
    if (!file) return res.status(400).json({ error: "Invalid type" });

    const data = readJson(file);
    if (!data[cat])
      return res.status(404).json({ error: "Category not found" });

    const numericId = parseInt(id, 10);
    const before = data[cat].length;
    data[cat] = data[cat].filter((item) => item.id !== numericId);
    if (before === data[cat].length)
      return res.status(404).json({ error: "Item not found" });

    writeJson(file, data);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// controllers/jsonController.js
exports.removeFlat = (req, res) => {
  try {
    const { type, id } = req.params;
    const file = FILE_MAP[type];
    if (!file) return res.status(400).json({ error: "Invalid type" });

    // phantomOptions.json is a plain array
    let data = readJson(file);
    const numericId = parseInt(id, 10);

    const before = data.length;
    data = data.filter(item => item.id !== numericId);
    if (data.length === before) {
      return res.status(404).json({ error: "Item not found" });
    }

    writeJson(file, data);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

