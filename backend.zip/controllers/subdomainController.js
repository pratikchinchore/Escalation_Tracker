const db = require("../model");

const Subdomain = db.Subdomain;

// Get all subdomains
exports.getAll = async (req, res) => {
  try {
    const data = await Subdomain.findAll({ order: [["domain_name", "ASC"]] });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Create subdomain
exports.create = async (req, res) => {
  try {
    const { domain_name, client_name } = req.body;
    if (!domain_name || !client_name) {
      return res.status(400).json({ error: "Both domain_name and client_name are required" });
    }
    const newSub = await Subdomain.create({ domain_name, client_name });
    res.json(newSub);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Update subdomain
exports.update = async (req, res) => {
  try {
    const { id, domain_name, client_name } = req.body;
    if (!id) return res.status(400).json({ error: "ID is required" });

    const sub = await Subdomain.findByPk(id);
    if (!sub) return res.status(404).json({ error: "Not found" });

    sub.domain_name = domain_name || sub.domain_name;
    sub.client_name = client_name || sub.client_name;
    await sub.save();

    res.json(sub);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Delete subdomain
exports.remove = async (req, res) => {
  try {
    const { id } = req.params;
    const sub = await Subdomain.findByPk(id);
    if (!sub) return res.status(404).json({ error: "Not found" });

    await sub.destroy();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
