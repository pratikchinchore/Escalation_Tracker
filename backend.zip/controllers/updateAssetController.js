const db = require("../model");
const UpdateAsset = db.UpdateAsset;

exports.createUpdateAsset = async (req, res) => {
  const { update_id, asset_title, asset_link, description } = req.body;

  try {
    const newUpdateAsset = await UpdateAsset.create({
      update_id,
      asset_title,
      asset_link,
      description,
    });

    res.status(201).json(newUpdateAsset);
  } catch (error) {
    console.error("Error creating update asset:", error);
    res.status(500).json({ error: "Failed to create update asset" });
  }
};
