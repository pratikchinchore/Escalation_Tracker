const db = require("../model");
const Update = db.Update;

exports.createUpdate = async (req, res) => {
  const {
    camp_id,
    description,
    allocationTime,
    campaignPickTime,
    internalPublishedTime,
    TAT,
    CT,
  } = req.body;

  const made_by = req.user.username || "Unknown";
  const role = req.user.role || "Unknown";
  const update_type = role === "Tester" ? "Internal Update" : "Client Update";
  const testing_status = role === "Tester" ? "Internal-Update" : "Pending";

  try {
    const newUpdate = await Update.create({
      camp_id,
      description,
      allocationTime,
      campaignPickTime,
      internalPublishedTime,
      TAT,
      CT,
      made_by,
      testing_status,
      update_type,
    });
    res.status(201).json(newUpdate);
  } catch (error) {
    console.error("Error creating update:", error);
    res.status(500).json({ error: "Failed to create update" });
  }
};

// controller/updateController.js
// controller/updateController.js
exports.updateUpdate = async (req, res) => {
  const { id } = req.params;
  const {
    description,
    allocationTime,
    campaignPickTime,
    internalPublishedTime,
    TAT,
    CT,
  } = req.body;

  const currentUser = req.user.username || "Unknown";

  try {
    const update = await Update.findByPk(id);
    if (!update) {
      return res.status(404).json({ error: "Update not found" });
    }

    // ✅ Append current user to made_by (avoid duplicates if already last one)
    if (update.made_by) {
      const madeByList = update.made_by.split("/");
      if (madeByList[madeByList.length - 1] !== currentUser) {
        update.made_by = `${update.made_by}/${currentUser}`;
      }
    } else {
      update.made_by = currentUser;
    }

    // ✅ Update fields
    update.description = description || update.description;
    update.allocationTime = allocationTime || update.allocationTime;
    update.campaignPickTime = campaignPickTime || update.campaignPickTime;
    update.internalPublishedTime =
      internalPublishedTime || update.internalPublishedTime;
    update.TAT = TAT || update.TAT;
    update.CT = CT || update.CT;

    // ✅ Always reset status to Pending
    update.testing_status = "Pending";

    await update.save();

    res.status(200).json(update);
  } catch (error) {
    console.error("Error updating update:", error);
    res.status(500).json({ error: "Failed to update update" });
  }
};


exports.getUpdatesByCampaign = async (req, res) => {
  const { campaignId, page = 1, limit = 5, searchTerm = "" } = req.query;
  const offset = (parseInt(page) - 1) * parseInt(limit);
  try {
    const { count, rows } = await db.Update.findAndCountAll({
      where: {
        camp_id: campaignId,
        description: {
          [db.Sequelize.Op.like]: `%${searchTerm}%`,
        },
      },
      offset: parseInt(offset),
      limit: parseInt(limit),
      order: [["createdAt", "DESC"]],
    });
    res.json({
      total: count,
      updates: rows,
    });
  } catch (err) {
    console.error("Error fetching updates:", err);
    res.status(500).json({ error: "Failed to fetch updates" });
  }
};

exports.updateTestingStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body; // Expected: "Done" or "Pending"

  try {
    const update = await db.Update.findByPk(id);
    if (!update) {
      return res.status(404).json({ error: "Update not found" });
    }

    update.testing_status = status;
    await update.save();

    res.status(200).json({ message: "Status updated", update });
  } catch (err) {
    console.error("Error updating testing status:", err);
    res.status(500).json({ error: "Failed to update status" });
  }
};

exports.getAllPendingCounts = async (req, res) => {
  try {
    const results = await db.Update.findAll({
      attributes: [
        "camp_id",
        "testing_status",
        [db.Sequelize.fn("COUNT", db.Sequelize.col("id")), "count"],
      ],
      where: {
        testing_status: {
          [db.Sequelize.Op.in]: ["Pending", "Internal-Update"],
        },
      },
      group: ["camp_id", "testing_status"], // ✅ group by both
    });

    const counts = {};
    results.forEach((r) => {
      const campId = r.get("camp_id");
      const status = r.get("testing_status");
      const count = parseInt(r.get("count"));

      if (!counts[campId]) {
        counts[campId] = { pending: 0, internalUpdate: 0 };
      }

      if (status === "Pending") {
        counts[campId].pending = count;
      } else if (status === "Internal-Update") {
        counts[campId].internalUpdate = count;
      }
    });

    res.json({ counts });
   // console.log(counts);
    
  } catch (err) {
    console.error("Error fetching all pending counts:", err);
    res.status(500).json({ error: "Failed to fetch all pending counts" });
  }
};

