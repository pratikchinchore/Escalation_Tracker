const { User } = require("../model");

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.findAll({
      where: { status: 1 },
      attributes: ["userId", "empID", "username", "role"], // exclude password
    });
    res.status(200).json(users);
  } catch (err) {
    console.error("Error fetching users:", err);
    res.status(500).json({ error: "Failed to fetch users" });
  }
};

exports.deleteUser = async (req, res) => {
  const { id } = req.params;
  try {
    await User.destroy({ where: { userId: id } });
    res.status(200).json({ message: "User deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: "Failed to delete user" });
  }
};

exports.createUser = async (req, res) => {
  try {
    const newUser = await User.create(req.body);
    res.status(201).json(newUser);
  } catch (err) {
    console.error("Create user error:", err);
    res
      .status(400)
      .json({ error: "Failed to create user", details: err.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    await User.update(req.body, { where: { userId: id } });
    res.status(200).json({ message: "User updated" });
  } catch (err) {
    res.status(400).json({ error: "Update failed" });
  }
};

exports.getCurrentUser = async (req, res) => {
  try {
  
    
    const user = await User.findByPk(req.user.id); // id from JWT
    if (!user) return res.status(404).json({ message: "User not found" });

    res.json({
      username: user.username,
      role: user.role,
      empID: user.empID,
    });
  } catch (err) {
    res.status(500).json({ message: "Error fetching user" });
  }
};


exports.deactivateUser = async (req, res) => {
  const { id } = req.params;
  try {
    await User.update(
      { status: 0 },
      { where: { userId: id } }
    );
    res.status(200).json({ message: "User deactivated successfully" });
  } catch (err) {
    res.status(500).json({ error: "Failed to deactivate user" });
  }
};

