const { verifyToken } = require('../utils/jwt');
const { User } = require("../model");
const bcrypt = require("bcrypt");

exports.authMiddleware = (req, res, next) => {
 // console.log("header",req);
  
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1]; // Format: Bearer <token>

  if (!token) return res.status(403).json({ message: "No token provided" });

  try {
    const decoded = verifyToken(token);
    req.user = decoded; // contains id, username, role
    next();
  } catch (err) {
    return res.status(403).json({ message: "Invalid token" });
  }
};

// For single role (e.g. Admin)
exports.roleMiddleware = (requiredRole) => {
  return (req, res, next) => {
    if (!req.user || req.user.role !== requiredRole) {
      return res.status(403).json({ message: "Access denied" });
    }
    next();
  };
};

// Optional: For multiple allowed roles
exports.allowRoles = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Insufficient permission" });
    }
    next();
  };
};


exports.updatePassword = async (req, res) => {
  console.log("NEW PASSWORD", req.body);
  
  const { username, newPassword } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await User.update(
      { password: hashedPassword },
      { where: { empID: username } }
    );

    res.status(200).json({ message: "Password updated successfully" });
  } catch (err) {
    console.error("Password update error:", err);
    res.status(500).json({ error: "Failed to update password" });
  }
};
