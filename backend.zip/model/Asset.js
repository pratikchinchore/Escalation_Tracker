// models/asset.js
module.exports = (sequelize, DataTypes) => {
  const Asset = sequelize.define("Asset", {
    asset: { type: DataTypes.STRING, allowNull: false },
    link: { type: DataTypes.STRING, allowNull: false },
    camp_id: { type: DataTypes.INTEGER, allowNull: false },
    link_type: { type: DataTypes.STRING },
    made_by: { type: DataTypes.STRING },
  });

  Asset.associate = (models) => {
    Asset.belongsTo(models.Link, {
      foreignKey: "camp_id",
      onDelete: "CASCADE",
    });
  };

  return Asset;
};
