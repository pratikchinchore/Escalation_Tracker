module.exports = (sequelize, DataTypes) => {
  const Asset = sequelize.define("Asset", {
    asset: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    link: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    camp_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    link_type: {
      type: DataTypes.STRING,
      allowNull: true, // set to false if you want it to be required
    },
    made_by: {
      type: DataTypes.STRING,
      allowNull: true, // set to false if you want it to be required
    },
  });

  Asset.associate = (models) => {
    Asset.belongsTo(models.Link, {
      foreignKey: "camp_id",
      onDelete: "CASCADE",
    });
  };

  return Asset;
};
