// models/link.js
module.exports = (sequelize, DataTypes) => {
  const Link = sequelize.define("Link", {
    Campaign_Name: { type: DataTypes.STRING, allowNull: false },
    internalId: { type: DataTypes.STRING,defaultValue: "N/A", },
    Country: { type: DataTypes.STRING, allowNull: false },
    Campaign_Type: { type: DataTypes.STRING, allowNull: false },
    ClientCode: { type: DataTypes.STRING, allowNull: false },
    allocationTime: { type: DataTypes.DATE, allowNull: false },
    campaignPickTime: { type: DataTypes.DATE },
    internalPublishedTime: { type: DataTypes.DATE },
    TAT: { type: DataTypes.STRING },
    CT: { type: DataTypes.STRING },
    description: { type: DataTypes.TEXT, allowNull: false },
    Comment: { type: DataTypes.TEXT },
    testing_status: {
      type: DataTypes.STRING,
      defaultValue: "Pending",
      allowNull: false,
    },
    made_by: { type: DataTypes.STRING },
  });

  Link.associate = (models) => {
    Link.hasMany(models.Asset, {
      foreignKey: "camp_id",
      as: "assets",
      onDelete: "CASCADE",
      hooks: true, // ✅ required for Sequelize CASCADE
    });

    Link.hasMany(models.Update, {
      foreignKey: "camp_id",
      as: "updates",
      onDelete: "CASCADE",
      hooks: true,
    });
  };

  return Link;
};
