module.exports = (sequelize, DataTypes) => {
  const Link = sequelize.define("Link", {
    Campaign_Name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    internalId: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    Country: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    Campaign_Type: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    ClientCode: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    allocationTime: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    campaignPickTime: {
      type: DataTypes.DATE,
      allowNull: true, // temporarily allow null
    },
    internalPublishedTime: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    TAT: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    CT: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    Comment: {
      type: DataTypes.TEXT,
      allowNull: true,
    },

    testing_status: {
      type: DataTypes.STRING,
      defaultValue: "Pending",
      allowNull: false,
    },
    made_by: {
      type: DataTypes.STRING,
      allowNull: true, // set to false if you want it to be required
    },
  });

  Link.associate = (models) => {
    Link.hasMany(models.Asset, {
      foreignKey: "camp_id",
      as: "assets",
    });
  };

  return Link;
};
