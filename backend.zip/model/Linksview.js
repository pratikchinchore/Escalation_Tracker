module.exports = (sequelize, DataTypes) => {
  const LinksView = sequelize.define(
    "LinksView",
    {
      Campaign_Type: DataTypes.STRING,
      internalId: DataTypes.STRING,
      ClientCode: DataTypes.STRING,
      Campaign_Name: DataTypes.STRING,
      createdAt: DataTypes.DATE,
      internalPublishedTime: DataTypes.DATE,
      allocationTime: DataTypes.DATE,
      TAT: DataTypes.STRING,
      made_by: DataTypes.STRING,
      link_type: DataTypes.STRING,
      asset_link: DataTypes.STRING,
      asset_title: DataTypes.STRING,
      Comment: DataTypes.TEXT,
    },
    {
      tableName: "links_view",
      timestamps: false,
    }
  );

  LinksView.associate = (models) => {
    LinksView.belongsTo(models.User, {
      foreignKey: "made_by",
      targetKey: "username",
      as: "User",
    });
  };
  return LinksView;
};
