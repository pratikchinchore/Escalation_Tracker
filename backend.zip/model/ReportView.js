module.exports = (sequelize, DataTypes) => {
  const ReportView = sequelize.define(
    "ReportView",
    {
      id: {
        type: DataTypes.VIRTUAL,
        primaryKey: true,
        get() {
          return null;
        },
      },
      Campaign_Type: DataTypes.STRING,
      internalId: DataTypes.STRING,
      ClientCode: DataTypes.STRING,
      Campaign_Name: DataTypes.STRING,
      createdAt: DataTypes.DATE,
      internalPublishedTime: DataTypes.DATE,
      allocationTime: DataTypes.DATE,
      TAT: DataTypes.STRING,
      made_by: DataTypes.STRING,
      link_type: DataTypes.STRING,
      link: DataTypes.STRING,
      asset: DataTypes.STRING,
      Comment: DataTypes.TEXT,
    },
    {
      tableName: "report_view",
      timestamps: false,
      createdAt: false,
      updatedAt: false,
    }
  );

  return ReportView;
};
