// models/Subdomain.js
module.exports = (sequelize, DataTypes) => {
  const Subdomain = sequelize.define(
    "Subdomain",
    {
      domain_name: {
        type: DataTypes.STRING,
        allowNull: false
      },
      client_name: {
        type: DataTypes.STRING,
        allowNull: false
      }
    },
    {
      tableName: "subdomains",
      timestamps: false // remove if you want createdAt/updatedAt
    }
  );

  return Subdomain;
};
