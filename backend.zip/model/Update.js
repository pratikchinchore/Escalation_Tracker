module.exports = (sequelize, DataTypes) => {
  const Update = sequelize.define("Update", {
    description: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    allocationTime: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    campaignPickTime: {
      type: DataTypes.DATE,
      allowNull: true, // temporarily allow null
    },
    internalPublishedTime: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    TAT: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    CT: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    update_type: {
      type: DataTypes.STRING,
      allowNull: true, // set to false if needed
    },
    made_by: {
      type: DataTypes.STRING,
      allowNull: true, // set to false if needed
    },

    testing_status: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: "Pending",
    },

    no_of_updates: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
  });

  Update.associate = (models) => {
    Update.belongsTo(models.Link, {
      foreignKey: "camp_id", // FK to Link table
      onDelete: "CASCADE",
    });
  };

  return Update;
};
