// models/update.js
module.exports = (sequelize, DataTypes) => {
  const Update = sequelize.define("Update", {
    description: { type: DataTypes.TEXT, allowNull: false },
    allocationTime: { type: DataTypes.DATE },
    campaignPickTime: { type: DataTypes.DATE },
    internalPublishedTime: { type: DataTypes.DATE },
    TAT: { type: DataTypes.STRING },
    CT: { type: DataTypes.STRING },
    update_type: { type: DataTypes.STRING },
    made_by: { type: DataTypes.STRING },
    testing_status: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: "Pending",
    },
    no_of_updates: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
  });

  Update.associate = (models) => {
    Update.belongsTo(models.Link, {
      foreignKey: "camp_id",
      onDelete: "CASCADE",
    });

    Update.hasMany(models.UpdateAsset, {
      foreignKey: "update_id",
      as: "updateAssets",
      onDelete: "CASCADE",
      hooks: true,
    });
  };

  return Update;
};
