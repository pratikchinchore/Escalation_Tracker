// models/updateasset.js
module.exports = (sequelize, DataTypes) => {
  const UpdateAsset = sequelize.define("UpdateAsset", {
    asset_title: { type: DataTypes.STRING, allowNull: false },
    asset_link: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.TEXT },
  });

  UpdateAsset.associate = (models) => {
    UpdateAsset.belongsTo(models.Update, {
      foreignKey: "update_id",
      onDelete: "CASCADE",
    });
  };

  return UpdateAsset;
};
