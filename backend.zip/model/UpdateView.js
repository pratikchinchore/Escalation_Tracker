module.exports = (sequelize, DataTypes) => {
  const UpdateView = sequelize.define(
    "UpdateView",
    {
      Campaign_Type: DataTypes.STRING,
      internalId: DataTypes.STRING,
      ClientCode: DataTypes.STRING,
      Campaign_Name: DataTypes.STRING,
      createdAt: DataTypes.DATE,
      internalPublishedTime: DataTypes.DATE,
      allocationTime: DataTypes.DATE,
      TAT: DataTypes.STRING,
      made_by: DataTypes.STRING,
      link_type: DataTypes.STRING,
      asset_link: DataTypes.STRING,
      asset_title: DataTypes.STRING,
      Comment: DataTypes.TEXT,
    },
    {
      tableName: "update_view",
      timestamps: false,
    }
  );

  return UpdateView;
};
