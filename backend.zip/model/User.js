const bcrypt = require("bcrypt");

module.exports = (sequelize, DataTypes) => {
  const User = sequelize.define("User", {
    userId: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    empID: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    username: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: "12345",
    },
    status: {
      type: DataTypes.STRING,
      allowNull: true,
      defaultValue: "1",
    },
    role: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  });

  // Hash password before saving
  User.beforeCreate(async (user) => {
    if (user.password) {
      user.password = await bcrypt.hash(user.password, 10);
    }
  });

 
User.associate = (models) => {
    User.hasMany(models.LinksView, {
      foreignKey: "made_by",
      sourceKey: "username",  // assuming made_by matches username
      as: "LinksViews"
    });
  };

  return User;
};
