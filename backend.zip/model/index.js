const Sequelize = require("sequelize");
const sequelize = new Sequelize("tracker_report_new", "root", "", {
  host: "localhost",
  dialect: "mysql",
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// Register models
db.Link = require("./Link")(sequelize, Sequelize.DataTypes);
db.User = require("./User")(sequelize, Sequelize.DataTypes);
db.Asset = require("./Asset")(sequelize, Sequelize.DataTypes);  
db.Update = require("./Update")(sequelize, Sequelize.DataTypes);
db.UpdateAsset = require("./UpdateAsset")(sequelize, Sequelize.DataTypes);
db.LinksView = require("./Linksview")(sequelize, Sequelize.DataTypes);
db.ReportView = require("./ReportView")(sequelize, Sequelize.DataTypes);
db.Subdomain = require("./Subdomain")(sequelize, Sequelize.DataTypes);


// Apply associations
Object.keys(db).forEach((modelName) => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

module.exports = db;
