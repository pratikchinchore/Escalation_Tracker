const express = require("express");
const router = express.Router();
const {
  authMiddleware,
  roleMiddleware,
  allowRoles,
  updatePassword,
} = require("../middleware/auth");

const authController = require("../controllers/authController");

router.post("/login", authController.login);

// ✅ Only logged-in users
router.get("/profile", authMiddleware, (req, res) => {
  res.json({ message: `Hello, ${req.user.username}`, role: req.user.role });
});

// ✅ Admin-only
router.get(
  "/admin/data",
  authMiddleware,
  roleMiddleware("Admin"),
  (req, res) => {
    res.json({ message: "Welcome Admin!" });
  }
);

// ✅ Admin or Manager
router.get(
  "/dashboard",
  authMiddleware,
  allowRoles("Admin", "Manager"),
  (req, res) => {
    res.json({ message: "Welcome to dashboard" });
  }
);

router.post("/update-password", updatePassword);

module.exports = router;
