const express = require("express");
const router = express.Router();


const dashboardController = require("../controllers/dashboardController");

router.get("/link-counts", dashboardController.getLinkCounts);
router.get("/report", dashboardController.getReportViewCounts);
router.get("/allreport", dashboardController.getAllReportViewData);

module.exports = router;