const express = require("express");
const router = express.Router();
const linkController = require("../controllers/linkController");
const { authMiddleware } = require("../middleware/auth");


router.post("/createLink", authMiddleware, linkController.createLink);
router.delete("/:id", authMiddleware, linkController.deleteLink);
router.get("/", linkController.getAllLinks);
router.post("/", linkController.createAssets);
router.get("/assets/:camp_id", linkController.getAssetsByCampaign);
router.post(
  "/append-link",
  authMiddleware,
  linkController.appendAdditionalLink
);

router.put("/status/:id", authMiddleware, linkController.updateCampaignStatus);
router.post("/check-duplicates", linkController.checkDuplicateLinks);



module.exports = router;
