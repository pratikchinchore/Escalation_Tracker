const express = require("express");
const router = express.Router();
const linkController = require("../controllers/linkController");
const { authMiddleware } = require("../middleware/auth");

// POST /api/links
router.post("/createLink", authMiddleware, linkController.createLink);
router.get("/", linkController.getAllLinks);
router.post("/", linkController.createAssets);
router.get("/assets/:camp_id", linkController.getAssetsByCampaign);
// router.post("/append-link", linkController.appendAdditionalLink);
router.post(
  "/append-link",
  authMiddleware,
  linkController.appendAdditionalLink
);

router.put("/status/:id", authMiddleware, linkController.updateCampaignStatus);
router.post("/check-duplicates", linkController.checkDuplicateLinks);


// You can add more routes here, like GET, PUT, DELETE
module.exports = router;
