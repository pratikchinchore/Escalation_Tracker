// routes/json.js
const express = require("express");
const router = express.Router();
const controller = require("../controllers/masterController");

router.get("/:type", controller.getAll);
router.post("/:type", controller.create);
router.put("/:type/:cat/:id", controller.update);
router.delete("/:type/:cat/:id", controller.remove);
router.delete('/:type/:id', controller.removeFlat);


module.exports = router;
