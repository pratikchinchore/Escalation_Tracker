// routes/updateAssetRoutes.js
const express = require("express");
const router = express.Router();
const updateAssetController = require("../controllers/updateAssetController");
const { authMiddleware } = require("../middleware/auth");

// Protect it with auth if needed:
router.post("/", authMiddleware, updateAssetController.createUpdateAsset);

module.exports = router;
