
const express = require("express");
const router = express.Router();
const updateAssetController = require("../controllers/updateAssetController");
const { authMiddleware } = require("../middleware/auth");

router.post("/", authMiddleware, updateAssetController.createUpdateAsset);

module.exports = router;
