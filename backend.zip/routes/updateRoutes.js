// routes/updateRoutes.js
const express = require("express");
const router = express.Router();
const updateController = require("../controllers/updateController");
const { authMiddleware } = require("../middleware/auth");

router.post("/", authMiddleware, updateController.createUpdate);
router.put("/:id", authMiddleware, updateController.updateUpdate);
router.get("/", updateController.getUpdatesByCampaign);
router.get("/pendingCount", updateController.getAllPendingCounts);
router.put("/:id/status", authMiddleware, updateController.updateTestingStatus);


module.exports = router;
