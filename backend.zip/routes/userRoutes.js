const express = require("express");
const router = express.Router();
const { authMiddleware, roleMiddleware } = require("../middleware/auth");
const {
  getAllUsers,
  deleteUser,
  createUser,
  updateUser,
  getCurrentUser,
  deactivateUser,
} = require("../controllers/userController");

router.get("/users", authMiddleware, roleMiddleware("Admin"), getAllUsers);
router.delete(
  "/users/:id",
  authMiddleware,
  roleMiddleware("Admin"),
  deleteUser
);
router.put("/users/:id/deactivate", deactivateUser);
router.post("/users", authMiddleware, roleMiddleware("Admin"), createUser);
router.put("/users/:id", authMiddleware, roleMiddleware("Admin"), updateUser);
router.get("/me", authMiddleware, getCurrentUser);

module.exports = router;
