
const jwt = require("jsonwebtoken");

const secretKey = "Pranav";  

exports.generateToken = (user) => {
  return jwt.sign(
    { id: user.id, role: user.role, username: user.username, empID:user.empID },
    secretKey,
    { expiresIn: "8h" }
  );
};

exports.verifyToken = (token) => {
  return jwt.verify(token, secretKey);
};
