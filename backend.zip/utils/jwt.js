
const jwt = require("jsonwebtoken");

const secretKey = "Pranav"; // Replace with .env later for security

exports.generateToken = (user) => {
  return jwt.sign(
    { id: user.id, role: user.role, username: user.username },
    secretKey,
    { expiresIn: "1h" }
  );
};

exports.verifyToken = (token) => {
  return jwt.verify(token, secretKey);
};
