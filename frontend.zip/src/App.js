import React, { useState, useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Navibar from "./Layout/Navibar";
import Home from "./Pages/Home";
import Footer from "./Layout/Footer";
import Header from "./Layout/Header";
import Linkform from "./Pages/User/Linkform";
import CampaignLinks from "./Pages/User/CampaignLinks";
import Login from "./Pages/Login";
import ProtectedRoute from "./ProtectedRoute";
import UserInfo from "./Pages/Admin/UserInfo";
import Tools from "./Pages/User/Tools";
import ParticlesBackground from "./components/ParticlesBackground";
import Dashboard from "./Pages/User/Dashboard";
import HeaderNav from "./Layout/HeaderNav";
import UnicodeConverter from "./Bookmarks/unicode_converter";
import OptionMaker from "./Bookmarks/OptionMaker";
import ListMaker from "./Bookmarks/ListMaker";
import UTF8Encoder from "./Bookmarks/UTF8Encoder";
import Replacer from "./Bookmarks/Replacer";
import LECompiler from "./Bookmarks/LECompiler";
import SubDomain from "./Bookmarks/SubDomain";
import Master from "./Pages/Admin/Master";
import "./App.css";


function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth <= 768;
      setIsMobile(mobile);
      setCollapsed(mobile);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const sidebarWidth = collapsed ? 80 : 250;
  const headerHeight = 60; // ✅ Only main header height
  //const headerNavHeight = 40; // ✅ Height of your sticky sub navbar
  const totalHeaderHeight = headerHeight; // Only the fixed Header pushes the content down

  const isAuthPage =
    location.pathname === "/Login" || location.pathname === "/Signup";

  if (isAuthPage) {
    return (
      <div className="fullscreen-centered">
        <ParticlesBackground />
        <Login />
      </div>
    );
  }

  return (
    <div style={{ height: "100vh", overflow: "hidden" }}>
      {/* ✅ Fixed main header */}
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          height: `${headerHeight}px`,
          zIndex: 1001,
          backgroundColor: "#fff",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
        }}
      >
        <Header />
      </div>

      {/* ✅ Sidebar */}
      <Navibar collapsed={collapsed} isMobile={isMobile} />

      {/* ✅ Main content area */}
      <div
        style={{
          marginTop: `${totalHeaderHeight}px`,
          marginLeft: `${sidebarWidth}px`,
          height: `calc(100vh - ${totalHeaderHeight}px)`,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            backgroundColor: "#f9f9f9",
          }}
        >
          {/* ✅ Sticky HeaderNav inside content */}
          <div
            style={{
              position: "sticky",
              top: 0,
              zIndex: 10,
            }}
          >
            <HeaderNav />
          </div>

          {/* ✅ Main page content */}
          <div style={{ padding: "15px" }}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route
                path="/Linkform"
                element={
                  <ProtectedRoute>
                    <Linkform />
                  </ProtectedRoute>
                }
              />
              <Route path="/CampaignLinks" element={<CampaignLinks />} />
              <Route path="/Updates" element={<Tools />} />
              <Route path="/UserInfo" element={<UserInfo />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/Login" element={<Login />} />
              <Route path="/UnicodeConverter" element={<UnicodeConverter />} />
              <Route path="/OptionMaker" element={<OptionMaker />} />
              <Route path="/Replacer" element={<Replacer />} />
              <Route path="/UTF8Encoder" element={<UTF8Encoder />} />
              <Route path="/ListMaker" element={<ListMaker />} />
              <Route path="/LECompiler" element={<LECompiler />} />
              <Route path="/SubDomain" element={<SubDomain />} />
              <Route path="/Master" element={<Master />} />
            </Routes>
          </div>
        </div>

        <div style={{ backgroundColor: "#fff" }}>
          <Footer />
        </div>
      </div>
    </div>
  );
}

export default App;
