import React, { useState, useEffect } from 'react';

const LECompiler = () => {
  const [inputCode, setInputCode] = useState('');
  const [codeEdit, setCodeEdit] = useState('');
  const [compiledCode, setCompiledCode] = useState('');
  const [previewHTML, setPreviewHTML] = useState('');
  const [showPopup, setShowPopup] = useState(false);

  let text_before_form = '';
  let text_after_form = '';

  useEffect(() => {
    const val = inputCode;
    const start = val.indexOf('\\u003cform');
    const endStr = '\\u003c/form>';
    const end = val.indexOf(endStr);

    if (start !== -1 && end !== -1) {
      text_before_form = val.substring(0, start);
      text_after_form = val.substring(end + endStr.length, val.length);
      const formText = val.substring(start, end + endStr.length);

      const formatted = formText
        .replaceAll('\\n', '\n')
        .replaceAll('\\u003c', '<')
        .replaceAll('\\"', '"');

      setCodeEdit(formatted);
    }
  }, [inputCode]);

  const handleCodeEditChange = (e) => {
    const html = { html: e.target.value };
    setCodeEdit(e.target.value);
    setPreviewHTML(html.html);
  };

  const handleCompile = () => {
    const val = inputCode;
    const start = val.indexOf('\\u003cform');
    const endStr = '\\u003c/form>';
    const end = val.indexOf(endStr);

    if (start !== -1 && end !== -1) {
      text_before_form = val.substring(0, start);
      text_after_form = val.substring(end + endStr.length, val.length);

      const finalCompiled = text_before_form +
        codeEdit.replaceAll('\n', '\\n')
          .replaceAll('<', '\\u003c')
          .replaceAll('"', '\\"') +
        text_after_form;

      setCompiledCode(finalCompiled);
    }
  };

  return (
    <div style={{ position: 'relative', height: '100vh', display: 'grid', gridTemplateRows: '0.1fr 1fr 0.1fr 0.1fr' }}>
      <textarea
        id="input_code"
        style={{ width: '100%' }}
        cols="60"
        rows="5"
        value={inputCode}
        onChange={(e) => setInputCode(e.target.value)}
      />

      <textarea
        id="code_edit"
        style={{ display: 'block', height: '100%', width: '100%' }}
        value={codeEdit}
        onChange={handleCodeEditChange}
      />

      <div>
        <button onClick={handleCompile}>Compile</button>
        <button onClick={() => setShowPopup(true)}>Preview</button>
      </div>

      <textarea
        id="compiled_code"
        cols="60"
        rows="5"
        value={compiledCode}
        readOnly
      />

      {showPopup && (
        <div style={{
          zIndex: 100,
          display: 'block',
          backgroundColor: 'red',
          position: 'fixed',
          top: 0,
          left: 0,
          height: '100vh',
          width: '100vw'
        }}>
          <div
            onClick={() => setShowPopup(false)}
            style={{ float: 'right', marginRight: 100, cursor: 'pointer' }}
          >
            Close
          </div>
          <div id="preview" dangerouslySetInnerHTML={{ __html: previewHTML }} />
        </div>
      )}
    </div>
  );
};

export default LECompiler;
