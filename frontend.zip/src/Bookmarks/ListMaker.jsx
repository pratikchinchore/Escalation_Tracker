import React, { useState } from "react";
import { InputTextarea } from "primereact/inputtextarea";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Checkbox } from "primereact/checkbox";

// Function to encode special characters into HTML entities
const encodeHTMLEntities = (str) => {
  return str.replace(/[\u00A0-\u9999<>\&"'']/gim, function (i) {
    return `&#${i.charCodeAt(0)};`;
  });
};

const ListMaker = () => {
  const [inputText, setInputText] = useState("");
  const [listItems, setListItems] = useState([]);
  const [isOrdered, setIsOrdered] = useState(false);
  const [convertEntities, setConvertEntities] = useState(false);

  const handleChange = (e) => {
    const text = e.target.value;
    setInputText(text);

    const items = text.split("\n").filter((item) => item.trim() !== "");
    setListItems(items);
  };

  const handleClear = () => {
    setInputText("");
    setListItems([]);
  };

  const renderHTMLList = () => {
    if (listItems.length === 0) return "";

    const tag = isOrdered ? "ol" : "ul";
    const list = listItems
      .map((item) => {
        const content = convertEntities ? encodeHTMLEntities(item) : item;
        return `<li>${content}</li>`;
      })
      .join("\n");

    return `<${tag}>\n${list}\n</${tag}>`;
  };

  return (
    <div className="converter-wrapper">
      <Card>
        {/* Header with title and checkbox on same row */}
        <div style={{ marginBottom: "1rem" }}>
          <h3 style={{ marginBottom: "0.5rem" }}>
            <b>📝 HTML List Maker</b>
          </h3>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              flexWrap: "wrap",
              alignItems: "center",
            }}
          >
            <div className="p-field-checkbox" style={{ display: "flex", alignItems: "center" }}>
              <Checkbox
                inputId="convertEntities"
                checked={convertEntities}
                onChange={(e) => setConvertEntities(e.checked)}
              />
              <label htmlFor="convertEntities" style={{ marginLeft: "0.5rem", fontSize: "0.85rem" }}>
                Convert to HTML Entities
              </label>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="p-fluid">
          <div className="p-field">
            <label htmlFor="inputText">Input List Items (One per line)</label>
            <InputTextarea
              id="inputText"
              value={inputText}
              onChange={handleChange}
              rows={6}
              placeholder="Enter items separated by new lines"
              style={{ height: "150px", overflow: "auto" }}
            />
          </div>

          <div className="p-field mt-3">
            <label htmlFor="htmlOutput">HTML List Output</label>
            <InputTextarea
              id="htmlOutput"
              value={renderHTMLList()}
              rows={6}
              readOnly
              style={{ height: "150px", overflow: "auto" }}
            />
          </div>
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "flex-end",
            marginTop: "1rem",
          }}
        >
          <Button
            label="Clear"
            icon="pi pi-times"
            className="p-button-sm p-button-rounded p-button-outlined p-button-danger"
            onClick={handleClear}
          />
        </div>
      </Card>
    </div>
  );
};

export default ListMaker;
