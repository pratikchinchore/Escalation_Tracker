import React, { useState, useRef } from "react";
import { InputTextarea } from "primereact/inputtextarea";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Toast } from "primereact/toast";
import { Checkbox } from "primereact/checkbox";
import "./Bookmarks.css";

import "primereact/resources/themes/saga-blue/theme.css";
import "primereact/resources/primereact.min.css";
import "primeicons/primeicons.css";

const OptionMaker = () => {
  const [labelsText, setLabelsText] = useState("");
  const [valuesText, setValuesText] = useState("");
  const [outputText, setOutputText] = useState("");
  const [convertToEntities, setConvertToEntities] = useState(false);
  const toast = useRef(null);

  const convertToHtmlEntity = (text) => {
    return [...text]
      .map((char) => {
        const code = char.codePointAt(0);
        return code >= 32 && code <= 126 ? char : `&#${code};`;
      })
      .join("");
  };

  const handleConvert = () => {
    const labels = labelsText
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    const values = valuesText
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    if (labels.length !== values.length) {
      toast.current.show({
        severity: "error",
        summary: "Mismatch!",
        detail: "Number of labels and values must match!",
        life: 3000,
      });
      return;
    }

    const options = labels
      .map((label, index) => {
        let value = values[index];
        let finalLabel = label;
        if (convertToEntities) {
          finalLabel = convertToHtmlEntity(label);
        }
        return `<option value="${value}">${finalLabel}</option>`;
      })
      .join("\n");

    setOutputText(options);
  };

  const handleClear = () => {
    setLabelsText("");
    setValuesText("");
    setOutputText("");
  };

  return (
    <div className="option-maker-wrapper">
      <Toast ref={toast} />
      <Card>
        {/* Header Section */}
        <div style={{ marginBottom: "1rem" }}>
          <h3 style={{ marginBottom: "0.5rem" }}>
            <b>HTML Option Maker</b>
          </h3>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              flexWrap: "wrap",
              alignItems: "center",
            }}
          >
            {/* Checkbox Left */}
            <div className="p-field-checkbox" style={{ display: "flex", alignItems: "center" }}>
              <Checkbox
                inputId="entityCheckbox"
                checked={convertToEntities}
                onChange={(e) => setConvertToEntities(e.checked)}
              />
              <label htmlFor="entityCheckbox" style={{ marginLeft: "0.5rem" }}>
                Convert to HTML Entities
              </label>
            </div>

            {/* Buttons Right */}
            <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.5rem" }}>
              <Button
                label="Get Options"
                icon="pi pi-check"
                className="p-button-sm p-button-rounded p-button-success"
                onClick={handleConvert}
              />
              <Button
                label="Clear"
                icon="pi pi-times"
                className="p-button-sm p-button-rounded p-button-danger p-button-outlined"
                onClick={handleClear}
              />
            </div>
          </div>
        </div>

        {/* Textarea Section */}
        <div className="grid-3-col">
          <div className="p-field input-block">
            <label htmlFor="valuesText">Option Values</label>
            <InputTextarea
              id="valuesText"
              value={valuesText}
              onChange={(e) => setValuesText(e.target.value)}
              rows={15}
              placeholder={`Example:\n1\n2`}
              style={{ height: "350px", overflow: "auto" }}
            />
          </div>

          <div className="p-field input-block">
            <label htmlFor="labelsText">Option Labels</label>
            <InputTextarea
              id="labelsText"
              value={labelsText}
              onChange={(e) => setLabelsText(e.target.value)}
              rows={15}
              placeholder={`Example:\nApple\nBanana`}
              style={{ height: "350px", overflow: "auto" }}
            />
          </div>

          <div className="p-field input-block output-block">
            <label htmlFor="outputText">Generated &lt;option&gt; Tags</label>
            <InputTextarea
              id="outputText"
              value={outputText}
              readOnly
              rows={15}
              placeholder={`<option value="1">Apple</option><option value="2">Banana</option>`}
              style={{ height: "350px", overflow: "auto", width: "70%" }}
            />
          </div>
        </div>
      </Card>
    </div>
  );
};

export default OptionMaker;
