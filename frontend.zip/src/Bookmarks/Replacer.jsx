import React, { useState } from "react";
import "./Bookmarks.css";
import { Button } from "primereact/button";

const Replacer = () => {
  const [inputText, setInputText] = useState("");
  const [searchFor, setSearchFor] = useState("");
  const [replaceWith, setReplaceWith] = useState("");
  const [outputText, setOutputText] = useState("");

  const handleReplace = () => {
    if (searchFor === "") {
      alert('Please enter a "Search For" value.');
      return;
    }
    const result = inputText.replace(new RegExp(searchFor, "g"), replaceWith);
    setOutputText(result);
  };
 
  const handleCopy = () => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      // Modern method
      navigator.clipboard
        .writeText(outputText)
        .then(() => {
          console.log("Copied to clipboard");
        })
        .catch((err) => {
          console.error("Clipboard copy failed:", err);
        });
    } else {
      // Fallback method using textarea
      const textArea = document.createElement("textarea");
      textArea.value = outputText;
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();

      try {
        const successful = document.execCommand("copy");
        if (successful) {
          console.log("Copied using fallback method");
        } else {
          console.error("Fallback copy failed");
        }
      } catch (err) {
        console.error("Fallback error:", err);
      }

      document.body.removeChild(textArea);
    }
  };

  const handleReset = () => {
    setInputText("");
    setSearchFor("");
    setReplaceWith("");
    setOutputText("");
  };

  const handleUppercase = () => {
    setOutputText(outputText.toUpperCase());
  };

  const handleLowercase = () => {
    setOutputText(outputText.toLowerCase());
  };

  return (
    <div className="tool-container">
      <h2 className="tool-heading">🛠️ Text Replacer</h2>

      <div className="tool-row">
        <input
          type="text"
          className="tool-input"
          placeholder="Search For"
          value={searchFor}
          onChange={(e) => setSearchFor(e.target.value)}
        />
        <input
          type="text"
          className="tool-input"
          placeholder="Replace With"
          value={replaceWith}
          onChange={(e) => setReplaceWith(e.target.value)}
        />
        <Button
          label="Replace"
          icon="pi pi-sync"
          className="p-button-sm p-button-outlined p-button-info"
          onClick={handleReplace}
        />
      </div>

      <div className="tool-textareas">
        <textarea
          className="tool-textarea"
          placeholder="Enter your input here..."
          rows={6}
          value={inputText}
          onChange={(e) => {
            setInputText(e.target.value);
            handleReplace();
          }}
        />
        <textarea
          className="tool-textarea"
          placeholder="Result will appear here..."
          rows={6}
          value={outputText}
          readOnly
        />
      </div>

      <div className="tool-buttons">
        <Button
          label="📋 Copy"
          className="p-button-sm p-button-success p-button-outlined"
          onClick={handleCopy}
        />
        <Button
          label="🔄 Reset"
          className="p-button-sm p-button-warning p-button-outlined"
          onClick={handleReset}
        />
        <Button
          label="🔠 UPPERCASE"
          className="p-button-sm p-button-secondary p-button-outlined"
          onClick={handleUppercase}
        />
        <Button
          label="🔡 lowercase"
          className="p-button-sm p-button-secondary p-button-outlined"
          onClick={handleLowercase}
        />
      </div>
    </div>
  );
};

export default Replacer;
