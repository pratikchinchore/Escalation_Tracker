import React, { useState, useEffect } from "react";
import api from "../axiosConfig";
import { Card } from "primereact/card";
import { Button } from "primereact/button";
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import { Dialog } from "primereact/dialog";
import { Dropdown } from "primereact/dropdown";
import { InputText } from "primereact/inputtext";

const SubDomain = () => {
  const [data, setData] = useState([]);
  const [showDialog, setShowDialog] = useState(false);
  const [domainName, setDomainName] = useState("");
  const [clientName, setClientName] = useState("");
  const [deleteMode, setDeleteMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const userRoles = localStorage.getItem("role");

  const domainOptions = [
    {
      label: "engage-b2b.biz-tech-insights.com",
      value: "engage-b2b.biz-tech-insights.com",
    },
    {
      label: "b2b-engage.biz-tech-insights",
      value: "b2b-engage.biz-tech-insights",
    },
    {
      label: "insight.biz-tech-insights.com",
      value: "insight.biz-tech-insights.com",
    },
    {
      label: "b2b-insight.biz-tech-insights.com",
      value: "b2b-insight.biz-tech-insights.com",
    },
    {
      label: "engage.biz-tech-insights.com",
      value: "engage.biz-tech-insights.com",
    },
  ];

  const [userInfo, setUserInfo] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await api.get("user/me", {
          headers: {
            Authorization: token,
          },
        });
        setUserInfo(res.data);
      } catch (err) {
        console.error("Failed to fetch user:", err);
      }
    };

    fetchUser();
  }, []);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = () => {
    api
      .get("/subdomain")
      .then((res) => setData(res.data))
      .catch((err) => console.error("Error fetching subdomain data:", err));
  };

  const addRow = async () => {
    if (!domainName || !clientName) {
      alert("Please fill in all fields.");
      return;
    }
    try {
      await api.post("/subdomain", {
        domain_name: domainName,
        client_name: clientName,
      });
      fetchData();
      setShowDialog(false);
      setDomainName("");
      setClientName("");
    } catch (err) {
      console.error("Add row failed", err);
    }
  };

  const deleteRow = async (id) => {
    confirmDialog({
      message: "Are you sure you want to delete this client?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      accept: async () => {
        try {
          await api.delete(`/subdomain/${id}`);
          fetchData();
        } catch (error) {
          console.error("Delete failed", error);
        }
      },
    });
  };

  // Highlight & bold search matches
  const highlightText = (text) => {
    if (!searchTerm.trim()) return text;
    const regex = new RegExp(`(${searchTerm})`, "gi");
    return text.replace(
      regex,
      `<mark style="background-color: #ffff54c4; font-weight: bold;">$1</mark>`
    );
  };

  // Filter only matching rows
  const filterData = () => {
    if (!searchTerm.trim()) return data;
    return data.filter((item) =>
      item.client_name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  const filteredData = filterData();
  const domainNames = domainOptions.map((opt) => opt.value);
  const groupedData = domainNames.reduce((acc, domain) => {
    acc[domain] = filteredData.filter((item) => item.domain_name === domain);
    return acc;
  }, {});

  return (
    <div style={{ padding: "1rem" }}>
      <Card
        style={{
          background: "#fdfdfd",
          borderRadius: "12px",
          padding: "0.1rem",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <ConfirmDialog />

        {/* Dialog */}
        <Dialog
          header="Add SubDomain"
          visible={showDialog}
          onHide={() => setShowDialog(false)}
          style={{ minWidth: "350px" }}
        >
          <div className="flex flex-column gap-3">
            <div>
              <label>
                <b>Domain Name</b>
              </label>
              <Dropdown
                value={domainName}
                options={domainOptions}
                onChange={(e) => setDomainName(e.value)}
                placeholder="Select Domain"
                className="w-full"
              />
            </div>
            <div>
              <label>
                <b>Client Name</b>
              </label>
              <InputText
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                placeholder="Enter Client Name"
                className="w-full"
              />
            </div>
            <div className="flex justify-content-end gap-2 mt-3">
              <Button
                label="Cancel"
                severity="secondary"
                outlined
                onClick={() => setShowDialog(false)}
              />
              <Button label="Save" icon="pi pi-check" onClick={addRow} />
            </div>
          </div>
        </Dialog>

        {/* Controls */}
        <div
          className="flex items-center w-full mb-3 gap-2"
          style={{
            borderBottom: "1px solid #e0e0e0",
            paddingBottom: "0.5rem",
            marginBottom: "1rem",
          }}
        >
          <h3 className="mr-auto">🌐 W8 SubDomain</h3>
          <InputText
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search..."
            className="p-inputtext-sm"
          />

          {userRoles?.includes("Admin") && (
            <Button
              icon="pi pi-plus"
              label="Add"
              onClick={() => setShowDialog(true)}
            />
          )}

          {userRoles?.includes("Admin") && (
            <Button
              icon="pi pi-trash"
              label="Delete"
              severity={deleteMode ? "danger" : "secondary"}
              outlined
              onClick={() => setDeleteMode(!deleteMode)}
            />
          )}
        </div>

        {/* Table with fixed height & scroll */}
        <div style={{ overflowX: "auto", overflowY: "auto", flex: 1 }}>
          <table
            className="p-datatable p-component"
            style={{ width: "100%", borderCollapse: "collapse" }}
          >
            <thead>
              <tr>
                {domainNames.map((domain) => (
                  <th
                    key={domain}
                    style={{
                      textAlign: "center",
                      padding: "8px",
                      background: "#f7f7f7",
                      fontWeight: "bold",
                    }}
                  >
                    {domain}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {Array.from({
                length: Math.max(
                  ...Object.values(groupedData).map((arr) => arr.length),
                  0
                ),
              }).map((_, rowIndex) => (
                <tr key={rowIndex}>
                  {Object.keys(groupedData).map((domain) => {
                    const client = groupedData[domain][rowIndex];
                    return (
                      <td
                        key={domain}
                        style={{ textAlign: "center", padding: "20px" }}
                      >
                        {client ? (
                          <div className="flex justify-content-center align-items-center gap-1">
                            <span
                              dangerouslySetInnerHTML={{
                                __html: highlightText(client.client_name),
                              }}
                            />
                            {deleteMode && (
                              <Button
                                icon="pi pi-trash"
                                severity="danger"
                                rounded
                                text
                                size="small"
                                onClick={() => deleteRow(client.id)}
                              />
                            )}
                          </div>
                        ) : null}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default SubDomain;
