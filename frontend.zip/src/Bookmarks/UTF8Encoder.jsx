import React, { useState } from "react";
import { Card } from "primereact/card";
import { InputTextarea } from "primereact/inputtextarea";
import { Button } from "primereact/button";

const UTF8EmailEncoder = () => {
  const [inputText, setInputText] = useState("");
  const [encodedText, setEncodedText] = useState("");

  const encodeToUtf8Base64 = (str) => {
    try {
      const utf8Bytes = unescape(encodeURIComponent(str));
      const base64 = btoa(utf8Bytes);
      return `=?UTF-8?B?${base64}?=`;
    } catch {
      return "Encoding failed!";
    }
  };

  const handleEncode = () => {
    setEncodedText(encodeToUtf8Base64(inputText));
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(encodedText);
      alert("Copied!");
    } catch {
      alert("Copy failed!");
    }
  };

  const handleReset = () => {
    setInputText("");
    setEncodedText("");
  };

  return (
    <div className="container mt-5" style={{ maxWidth: "1000px", margin: "0 auto" }}>
      <Card title="UTF-8 Email Subject Encoder" className="shadow-md">
        <p style={{ fontSize: "14px", color: "#6c757d" }}>
          Encode your email subject to UTF-8 Base64 format like: <br />
          <code>=?UTF-8?B?....?=</code>
        </p>

        <div className="mb-3">
          <label className="font-semibold">Input Subject</label>
          <InputTextarea
            rows={4}
            value={inputText}
            placeholder="Enter email subject"
            onChange={(e) => setInputText(e.target.value)}
            className="w-full mt-1"
          />
        </div>

        <div className="mb-3">
          <label className="font-semibold">Encoded Result</label>
          <InputTextarea
            rows={4}
            value={encodedText}
            readOnly
            placeholder="Encoded UTF-8 string"
            className="w-full mt-1"
          />
        </div>

        <div className="flex gap-2 mt-2">
          <Button label="Encode" icon="pi pi-lock" onClick={handleEncode} className="p-button-success" />
          <Button label="Copy" icon="pi pi-copy" onClick={handleCopy} className="p-button-secondary" />
          <Button label="Reset" icon="pi pi-times" onClick={handleReset} className="p-button-danger p-button-outlined" />
        </div>
      </Card>
    </div>
  );
};

export default UTF8EmailEncoder;
