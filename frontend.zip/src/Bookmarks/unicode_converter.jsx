import React, { useState } from "react";
import { InputTextarea } from "primereact/inputtextarea";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import "./Bookmarks.css";

const UnicodeConverter = () => {
  const [inputText, setInputText] = useState("");
  const [convertedText, setConvertedText] = useState("");

  const handleChange = (e) => {
    const text = e.target.value;
    setInputText(text);

    const converted = [...text]
      .map((char) => {
        const code = char.codePointAt(0);
        if (code >= 32 && code <= 126) {
          return char;
        } else {
          return `&#${code};`;
        }
      })
      .join("");

    setConvertedText(converted);
  };

  const handleClear = () => {
    setInputText("");
    setConvertedText("");
  };

  return (
    <div className="converter-wrapper">
      <Card title="Unicode ➜ HTML Entity Converter">
        <div className="p-fluid">
          <div className="p-field">
            <label htmlFor="inputText">Input Text</label>
            <InputTextarea
              id="inputText"
              value={inputText}
              onChange={handleChange}
              rows={6}
              placeholder="Type or paste text..."
              style={{ height: "150px", overflow: "auto" }}
            />
          </div>

          <div className="p-field mt-3">
            <label htmlFor="convertedText">Converted Output</label>
            <InputTextarea
              id="convertedText"
              value={convertedText}
              rows={6}
              readOnly
              style={{ height: "150px", overflow: "auto" }}
            />
          </div>
        </div>

        {/* ✅ Button NOT inside p-fluid */}
        <div
          style={{
            display: "flex",
            justifyContent: "flex-end",
            marginTop: "1rem",
          }}
        >
          <Button
            label="Clear"
            icon="pi pi-times"
            className="p-button-sm p-button-rounded p-button-outlined p-button-danger"
            onClick={handleClear}
          />
        </div>
      </Card>
    </div>
  );
};

export default UnicodeConverter;
