const Footer = () => (
  <div className="app-footer">Copyright © 2025 XDBS Corporation</div>
);

export default Footer;
