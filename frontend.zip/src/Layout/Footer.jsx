const Footer = () => (
  <div
    style={{
      textAlign: "center",
      padding: "10px 0",
      fontSize: "14px",
      color: "#777",
      borderTop: "1px solid #eee",
    }}
  >
    Copyright © 2025 XDBS Corporation
  </div>
);

export default Footer;
