import React, { useEffect, useState } from "react";
import { FaUserCircle } from "react-icons/fa";
import { Link, useLocation } from "react-router-dom";
import api from "../axiosConfig";
import "./Navibar.css";
import OndirectLogo from "../Images/ondirect-logo.png";
const Header = () => {
  const [userInfo, setUserInfo] = useState(null);
  const location = useLocation();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await api.get("user/me", {
          headers: {
            Authorization: token,
          },
        });
        setUserInfo(res.data);
      } catch (err) {
        console.error("Failed to fetch user:", err);
      }
    };

    fetchUser();
  }, []);

  return (
    <>
      <header
        className="sticky-top d-flex align-items-center justify-content-between px-3"
        style={{
          backgroundColor: "#343a40",
          color: "#fff",
          height: "60px",
          zIndex: 1030,
        }}
      >
        {/* Logo */}
        <div className="d-flex align-items-center">
          <img
            src={OndirectLogo}
            alt="Logo"
            style={{ height: "40px", backgroundColor: "white" }}
          />
        </div>

        {/* Title */}
        <div className="text-center flex-grow-1 d-none d-md-block">
          <p className="m-0" style={{ fontSize: "1.3rem", fontWeight: "bold" }}>
            Tracker Report
          </p>
        </div>

        {/* User Info */}
        <div className="d-flex align-items-center gap-2 text-end">
          <FaUserCircle size={36} />
          <div className="text-end">
            <p className="m-0 fw-semibold">{userInfo?.username || "..."}</p>
            <p className="m-0" style={{ fontSize: "0.85rem" }}>
              {/* {userInfo?.role || "Role"}{" "} */}
              {/* {userInfo?.empID && `| EMP ID: ${userInfo.empID}`} */}
              {userInfo?.role} || {userInfo?.empID}
            </p>
          </div>
        </div>  
      
      </header>
    </>
  );
};

export default Header;
