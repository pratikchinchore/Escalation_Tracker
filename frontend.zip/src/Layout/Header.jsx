import React, { useContext } from "react";
import { FaUserCircle } from "react-icons/fa";
import OndirectLogo from "../Images/ondirect-logo.png";
import { AuthContext } from "../contexts/AuthContext";
import "./Navibar.css";

const Header = () => {
  const { auth } = useContext(AuthContext);

  return (
    <header className="app-header">
      {/* Logo */}
      <div className="logo-container">
        <img src={OndirectLogo} alt="Logo" className="logo" />
      </div>

      {/* Title */}
      <div className="header-title">
        <p>Trace Point</p>
      </div>

      {/* User Info */}
      <div className="user-info">
        <div className="user-avatar">
          <FaUserCircle />
        </div>
        <div className="user-text">
          <p className="username">{auth?.decoded?.username || "..."}</p>
          <p className="user-role">
            {auth?.decoded?.role || "Role"} | {auth?.decoded?.empID || "EMP"}
          </p>
        </div>
      </div>
    </header>
  );
};

export default Header;
