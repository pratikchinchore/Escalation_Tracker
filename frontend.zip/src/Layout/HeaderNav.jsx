import React from "react";
import { Link, useLocation } from "react-router-dom";

const HeaderNav = () => {
  const location = useLocation();
  return (
    <nav
      className="d-flex gap-4 px-3 py-1"
      style={{
        backgroundColor: "#495057",
        color: "#fff",
        height: "25px",
        display: "flex",
        alignItems: "center",
        gap: "20px",
        padding: "0 20px",
      }}
    >
      <Link
        to="/UnicodeConverter"
        className={`nav-link ${
          location.pathname === "/UnicodeConverter" ? "active" : ""
        }`}
        style={{ color: "#fff" }}
      >
        Unicode Convertor
      </Link>
      <Link
        to="/OptionMaker"
        className={`nav-link ${
          location.pathname === "/OptionMaker" ? "active" : ""
        }`}
        style={{ color: "#fff" }}
      >
        Option Maker
      </Link>
      <Link
        to="/UTF8Encoder"
        className={`nav-link ${
          location.pathname === "/UTF8Encoder" ? "active" : ""
        }`}
        style={{ color: "#fff" }}
      >
        UTF-8 Encoder
      </Link>
      <Link
        to="/ListMaker"
        className={`nav-link ${
          location.pathname === "/ListMaker" ? "active" : ""
        }`}
        style={{ color: "#fff" }}
      >
        List Maker
      </Link>
      <Link
        to="/Replacer"
        className={`nav-link ${
          location.pathname === "/Replacer" ? "active" : ""
        }`}
        style={{ color: "#fff" }}
      >
        Replacer
      </Link>
       <Link
        to="/SubDomain"
        className={`nav-link ${
          location.pathname === "/SubDomain" ? "active" : ""
        }`}
        style={{ color: "#fff" }}
      >
        W8 Sub Domain
      </Link>
      {/* <Link
        to="/LECompiler"
        className={`nav-link ${
          location.pathname === "/LECompiler" ? "active" : ""
        }`}
        style={{ color: "#fff" }}
      >
        LE Compiler
      </Link> */}
    </nav>
  );
};

export default HeaderNav;
