import React, { useContext } from "react";
import { Menu, MenuItem } from "react-pro-sidebar";
import { Link, useLocation } from "react-router-dom";
import "./Navibar.css";
import {
  FaTachometerAlt,
  FaWpforms,
  FaLink,
  FaUserCircle,
  FaDatabase,
  FaSignOutAlt,
} from "react-icons/fa";
import { AuthContext } from "../contexts/AuthContext";

const Navibar = ({ collapsed }) => {
  const location = useLocation();
  const {auth,logout}=useContext(AuthContext)
  const sidebarWidth = collapsed ? 80 : 250;
  const storedRoles = auth?.decoded?.role;
  const userRoles = storedRoles
    ? storedRoles.split(",").map((r) => r.trim().toLowerCase())
    : [];

  const menuItems = [
    {
      label: "Dashboard",
      icon: <FaTachometerAlt />,
      path: "/dashboard",
      roles: ["Admin", "Tester", "PHP-Developer"],
    },
    {
      label: "Add Links",
      icon: <FaWpforms />,
      path: "/Linkform",
      roles: ["Admin", "Tester", "PHP-Developer"],
    },
    {
      label: "Campaign & Links",
      icon: <FaLink />,
      path: "/CampaignLinks",
      roles: ["Admin", "Tester", "PHP-Developer"],
    },
    {
      label: "User Info",
      icon: <FaUserCircle />,
      path: "/UserInfo",
      roles: ["Admin"],
    },
    {
      label: "Master",
      icon: <FaDatabase />,
      path: "/Master",
      roles: ["Admin"],
    },
  ];

  // ✅ Utility: Check if user has permission
  const hasAccess = (allowedRoles) =>
    allowedRoles.some((role) => userRoles.includes(role.toLowerCase()));

  return (
    <div
      className="main_container"
      style={{
        width: sidebarWidth,
        minWidth: sidebarWidth,
        maxWidth: sidebarWidth,
      }}
    >
      <div className="sidebar_inner">
        <div>
          <Menu
            menuItemStyles={{
              button: ({ level, active }) => {
                if (level === 0)
                  return {
                    color: "#333",
                    backgroundColor: active ? "#dfd0d0b0" : "transparent",
                    fontWeight: active ? "600" : "normal",
                    borderRadius: "8px",
                    margin: "8px 10px",
                    transition: "background 0.3s",
                  };
              },
            }}
          >
            {menuItems.map((item) =>
              hasAccess(item.roles) ? (
                <MenuItem
                  key={item.path}
                  icon={item.icon}
                  component={<Link to={item.path} />}
                  active={location.pathname === item.path}
                >
                  {!collapsed && item.label}
                </MenuItem>
              ) : null
            )}
          </Menu>
        </div>

        {/* Logout */}
        <div className="logout_section">
          <Menu>
            <MenuItem
              icon={<FaSignOutAlt color="white" title="Logout" />}
              onClick={() => {
               logout()
              }}
              className={`logout_btn ${collapsed ? "collapsed" : ""}`}
            >
              {!collapsed && "Logout"}
            </MenuItem>
          </Menu>
        </div>
      </div>
    </div>
  );
};

export default Navibar;
