import React, { useContext } from "react";
import { NavLink } from "react-router-dom";
import {
  FaTachometerAlt,
  FaUserCircle,
  FaDatabase,
  FaLink,
  FaWpforms,
  FaSignOutAlt,
} from "react-icons/fa";
import "./Navibar.css";
import { AuthContext } from "../contexts/AuthContext";

const Navibar = () => {
  const { auth, logout } = useContext(AuthContext);

  const storedRoles = auth?.decoded?.role;
  const userRoles = storedRoles
    ? storedRoles.split(",").map((r) => r.trim().toLowerCase())
    : [];

  const hasAccess = (roles) =>
    roles.some((role) => userRoles.includes(role.toLowerCase()));

  const menuItems = [
    {
      name: "Dashboard",
      icon: <FaTachometerAlt />,
      path: "/dashboard",
      roles: ["Admin", "Tester", "PHP-Developer"],
    },
    {
      name: "Add Links",
      icon: <FaWpforms />,
      path: "/Linkform",
      roles: ["Admin", "Tester", "PHP-Developer"],
    },
    {
      name: "Campaign & Links",
      icon: <FaLink />,
      path: "/CampaignLinks",
      roles: ["Admin", "Tester", "PHP-Developer"],
    },
    {
      name: "User Info",
      icon: <FaUserCircle />,
      path: "/UserInfo",
      roles: ["Admin"],
    },
    {
      name: "Master",
      icon: <FaDatabase />,
      path: "/Master",
      roles: ["Admin"],
    },
  ];

  return (
    <div className="sidebar">
      <div className="menu">
        {menuItems.map(
          (item) =>
            hasAccess(item.roles) && (
              <NavLink
                key={item.name}
                to={item.path}
                className={({ isActive }) =>
                  isActive ? "sidebar-item active" : "sidebar-item"
                }
              >
                <div className="icon">{item.icon}</div>
                <div className="label">{item.name}</div>
              </NavLink>
            )
        )}
      </div>

      {/* Logout button styled like menu item */}
      <div className="menu logout-section">
        <button className="sidebar-item logout-btn" onClick={logout}>
          <div className="icon">
            <FaSignOutAlt />
          </div>
          <div className="label">Logout</div>
        </button>
      </div>
    </div>
  );
};

export default Navibar;
