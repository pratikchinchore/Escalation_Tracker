import React from 'react'

const Master = () => {
  return (
    <div>Master</div>
  )
}

export default Master