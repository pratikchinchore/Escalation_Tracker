import React, { useState, useEffect } from "react";
import api from "../../axiosConfig";
import { Card } from "primereact/card";
import { Button } from "primereact/button";
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import { Dialog } from "primereact/dialog";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";

/* ---------- Client Codes Table (pivot by category) ---------- */
const ClientCodesCard = ({ fileType, title }) => {
  const [data, setData] = useState({});
  const [categories, setCategories] = useState([]);
  const [dialog, setDialog] = useState(false);
  const [form, setForm] = useState({ label: "", value: "", category: "" });
  const [editing, setEditing] = useState(null);
  const [deleteMode, setDeleteMode] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const res = await api.get(`/${fileType}`);
      const json = res.data || {};
      setData(json);
      setCategories(Object.keys(json));
    } catch (err) {
      console.error(err);
    }
  };

  const handleSave = async () => {
    try {
      if (editing) {
        await api.put(`/${fileType}/${editing}`, form);
      } else {
        await api.post(`/${fileType}`, form);
      }
      setForm({ label: "", value: "", category: "" });
      setEditing(null);
      setDialog(false);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = (cat, id) => {
    confirmDialog({
      message: `Delete from ${cat}?`,
      header: "Confirm",
      icon: "pi pi-exclamation-triangle",
      accept: async () => {
        try {
          await api.delete(`/${fileType}/${cat}/${id}`);
          fetchData();
        } catch (err) {
          console.error("Delete failed", err);
        }
      },
    });
  };

  const maxRows = Math.max(...categories.map((c) => (data[c] || []).length), 0);

  return (
    <Card className="shadow-sm" style={{ borderRadius: 12, width: "100%" }}>
      <ConfirmDialog />
      {/* Header */}
      <div
        className="flex items-center gap-2 pb-3 mb-2"
        style={{ borderBottom: "1px solid #ddd" }}
      >
        <h4 className="mr-auto pt-2" style={{ margin: 0, fontSize: "1.4rem" }}>
          {title}
        </h4>
        <Button
          icon="pi pi-plus"
          size="small"
          onClick={() => {
            setForm({ label: "", value: "", category: "" });
            setEditing(null);
            setDialog(true);
          }}
        />
        <Button
          icon="pi pi-trash"
          size="small"
          outlined
          severity={deleteMode ? "danger" : "secondary"}
          onClick={() => setDeleteMode(!deleteMode)}
        />
      </div>

      {/* Add/Edit Dialog */}
      <Dialog
        header={editing ? "✏️ Edit Client Code" : "➕ Add Client Code"}
        visible={dialog}
        onHide={() => setDialog(false)}
        style={{ width: "420px" }} // keep it compact
      >
        <div className="flex flex-column gap-3" style={{ padding: "0.5rem" }}>
          {/* Label */}
          <div className="flex flex-column gap-1">
            <label htmlFor="ccLabel" style={{ fontWeight: 600 }}>
              Label
            </label>
            <InputText
              id="ccLabel"
              value={form.label}
              placeholder="Enter label"
              onChange={(e) => setForm({ ...form, label: e.target.value })}
            />
          </div>

          {/* Value */}
          <div className="flex flex-column gap-1">
            <label htmlFor="ccValue" style={{ fontWeight: 600 }}>
              Value
            </label>
            <InputText
              id="ccValue"
              value={form.value}
              placeholder="Enter value"
              onChange={(e) => setForm({ ...form, value: e.target.value })}
            />
          </div>

          {/* Category */}
          <div className="flex flex-column gap-1">
            <label htmlFor="ccCategory" style={{ fontWeight: 600 }}>
              Category
            </label>
            <Dropdown
              id="ccCategory"
              value={form.category}
              options={categories.map((c) => ({ label: c, value: c }))}
              placeholder="Select category"
              onChange={(e) => setForm({ ...form, category: e.value })}
              style={{ width: "100%" }}
            />
          </div>

          {/* Action Row */}
          <div className="flex justify-content-end gap-2 pt-3">
            <Button
              label="Cancel"
              size="small"
              severity="secondary"
              outlined
              onClick={() => setDialog(false)}
            />
            <Button
              label={editing ? "Update" : "Save"}
              size="small"
              icon="pi pi-check"
              onClick={handleSave}
            />
          </div>
        </div>
      </Dialog>

      {/* Pivot Table */}
      <div style={{ overflowX: "auto" }}>
        <table
          className="p-datatable p-component"
          style={{ width: "100%", border: "1px solid #e0e0e0" }}
        >
          <thead>
            <tr>
              {categories.map((c) => (
                <th
                  key={c}
                  style={{ textAlign: "left", padding: 15, fontSize: "1.2rem" }}
                >
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: maxRows }).map((_, rowIdx) => (
              <tr
                key={rowIdx}
                style={{ transition: "background 0.2s", cursor: "pointer" }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = "#f7f7f7")
                }
                onMouseLeave={(e) => (e.currentTarget.style.background = "")}
              >
                {categories.map((cat) => {
                  const entry = (data[cat] || [])[rowIdx];
                  return (
                    <td key={cat} style={{ padding: 15, fontSize: "0.95rem" }}>
                      {entry && (
                        <div
                          className="flex items-center"
                          style={{ justifyContent: "space-between" }}
                        >
                          <span className="pt-3">
                            {entry.label || entry.value}
                          </span>
                          {/* keep a fixed box for trash icon to prevent jump */}
                          <div
                            style={{
                              width: "1.5rem",
                              textAlign: "right",
                              visibility: deleteMode ? "visible" : "hidden",
                            }}
                          >
                            <Button
                              icon="pi pi-trash"
                              text
                              rounded
                              size="small"
                              severity="danger"
                              onClick={() => handleDelete(cat, entry.id)}
                            />
                          </div>
                        </div>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

/* ---------- Phantom Table ---------- */
const PhantomCard = ({ fileType, title }) => {
  const [rows, setRows] = useState([]);
  const [dialog, setDialog] = useState(false);
  const [form, setForm] = useState({ label: "", value: "" });
  const [deleteMode, setDeleteMode] = useState(false);

  const fetchRows = async () => {
    const res = await api.get(`/${fileType}`);
    setRows(res.data || []);
  };
  useEffect(() => {
    fetchRows();
  }, []);

  const save = async () => {
    await api.post(`/${fileType}`, { label: form.label, value: form.value });
    setForm({ label: "", value: "" });
    setDialog(false);
    fetchRows();
  };
  // Delete row by id
  const handleDelete = (id) => {
    confirmDialog({
      message: "Delete this row?",
      header: "Confirm",
      icon: "pi pi-exclamation-triangle",
      accept: async () => {
        try {
          await api.delete(`/${fileType}/${id}`);
          fetchRows();
        } catch (err) {
          console.error("Phantom delete failed", err);
        }
      },
    });
  };
  return (
    <Card className="shadow-sm" style={{ borderRadius: 12, width: "60%" }}>
      <ConfirmDialog />
      <div
        className="flex items-center pb-3 mb-2 gap-2"
        style={{ borderBottom: "1px solid #ddd" }}
      >
        <h4 className="mr-auto" style={{ margin: 0, fontSize: "1.4rem" }}>
          {title}
        </h4>
        <Button
          icon="pi pi-plus"
          size="small"
          onClick={() => setDialog(true)}
        />
        <Button
          icon="pi pi-trash"
          size="small"
          outlined
          severity={deleteMode ? "danger" : "secondary"}
          onClick={() => setDeleteMode(!deleteMode)}
        />
      </div>

      {/* Dialog with label & value */}
      <Dialog
        header="➕ Add Phantom Option"
        visible={dialog}
        onHide={() => setDialog(false)}
        style={{ width: "400px" }} // narrower card-like dialog
      >
        <div className="flex flex-column gap-3" style={{ padding: "0.5rem" }}>
          {/* Label field */}
          <div className="flex flex-column gap-1">
            <label htmlFor="phantomLabel" style={{ fontWeight: 600 }}>
              Label
            </label>
            <InputText
              id="phantomLabel"
              value={form.label}
              placeholder="Enter label"
              onChange={(e) => setForm({ ...form, label: e.target.value })}
            />
          </div>

          {/* Value field */}
          <div className="flex flex-column gap-1">
            <label htmlFor="phantomValue" style={{ fontWeight: 600 }}>
              Value
            </label>
            <InputText
              id="phantomValue"
              value={form.value}
              placeholder="Enter value"
              onChange={(e) => setForm({ ...form, value: e.target.value })}
            />
          </div>

          {/* Action buttons */}
          <div className="flex justify-content-end gap-2 pt-3">
            <Button
              label="Cancel"
              size="small"
              severity="secondary"
              outlined
              onClick={() => setDialog(false)}
            />
            <Button
              label="Save"
              size="small"
              icon="pi pi-check"
              onClick={save}
            />
          </div>
        </div>
      </Dialog>

      <table className="p-datatable p-component" style={{ width: "100%" }}>
        <thead>
          <tr>
            <th style={{ textAlign: "left", padding: 15 }}>Label</th>
            {deleteMode && <th>Action</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td style={{ padding: 15 }}>{r.label}</td>
              {deleteMode && (
                <td style={{ textAlign: "right" }}>
                  <Button
                    icon="pi pi-trash"
                    text
                    rounded
                    size="small"
                    severity="danger"
                    onClick={() => handleDelete(r.id)}
                  />
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </Card>
  );
};

/* ---------- Layout ---------- */
const JsonCrud = () => (
  <div
    className="flex flex-col gap-4"
    style={{ padding: "1rem", maxWidth: "1200px", margin: "0 auto" }}
  >
    <ClientCodesCard fileType="master" title="📋 Client Codes" />
    <PhantomCard fileType="phantom" title="📋 Phantom Option" />
  </div>
);

export default JsonCrud;
