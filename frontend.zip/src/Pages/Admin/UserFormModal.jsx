import React, { useEffect } from "react";
import { Dialog } from "primereact/dialog";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Button } from "primereact/button";
import { Controller, useForm } from "react-hook-form";

const roles = [
  { label: "Admin", value: "Admin" },
  { label: "PHP-Developer", value: "PHP-Developer" },
  { label: "Tester", value: "Tester" },
];

const UserFormModal = ({ visible, onHide, onSubmit, user }) => {
  const {
    register,
    handleSubmit,
    reset,
    setValue,
    control,
    formState: { errors },
  } = useForm();

  useEffect(() => {
    if (visible) {
      if (user) {
        setValue("username", user.username);
        setValue("empID", user.empID);
        setValue("role", user.role);
      } else {
        reset();  
      }
    } else {
      reset();  
    }
  }, [user, visible, setValue, reset]);

  return (
    <Dialog
      header={user ? "Edit User" : "Add User"}
      visible={visible}
      style={{ width: "400px" }}
      modal
      onHide={onHide}
    >
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-3">
          <label>Employee ID</label>
          <InputText
            {...register("empID", { required: true })}
            className="w-100"
          />
          {errors.empID && <small className="text-danger">Required</small>}
        </div>

        <div className="mb-3">
          <label>Username</label>
          <InputText
            {...register("username", { required: true })}
            className="w-100"
          />
          {errors.username && <small className="text-danger">Required</small>}
        </div>

        <div className="mb-3">
          <label>Role</label>
          <Controller
            name="role"
            control={control}
            rules={{ required: true }}
            render={({ field }) => (
              <Dropdown
                {...field}
                options={roles}
                placeholder="Select a role"
                className="w-100"
              />
            )}
          />
          {errors.role && <small className="text-danger">Required</small>}
        </div>

        <Button label="Submit" type="submit" className="mt-2 w-100" />
      </form>
    </Dialog>
  );
};

export default UserFormModal;
