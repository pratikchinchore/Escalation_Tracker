import React, { useEffect, useState, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { Toast } from "primereact/toast";
import { Divider } from "primereact/divider";
import { Tag } from "primereact/tag";
import { IconField } from "primereact/iconfield";
import { InputIcon } from "primereact/inputicon";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import api from "../../axiosConfig";
import UserFormModal from "./UserFormModal";
import { ConfirmDialog } from "primereact/confirmdialog";
import { confirmDialog } from "primereact/confirmdialog";

const UserList = () => {
  const [users, setUsers] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const toast = useRef(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const res = await api.get("user/users");
      setUsers(res.data);
    } catch (err) {
      toast.current.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to fetch users",
        life: 3000,
      });
    }
  };

  const handleEdit = (user) => {
    setEditingUser(user);
    setModalVisible(true);
  };

  const handleAdd = () => {
    setEditingUser(null);
    setModalVisible(true);
  };

  const handleModalSubmit = async (formData) => {
    try {
      if (editingUser) {
        await api.put(`user/users/${editingUser.userId}`, formData);
        toast.current.show({ severity: "success", summary: "User updated" });
      } else {
        await api.post("user/users", formData);
        toast.current.show({ severity: "success", summary: "User created" });
      }
      fetchUsers();
      setModalVisible(false);
      setEditingUser(null);
    } catch (err) {
      toast.current.show({ severity: "error", summary: "Action failed" });
    }
  };

  const handleDelete = (userId) => {
    confirmDialog({
      message: "Are you sure you want to delete this user?",
      header: "Confirmation",
      icon: "pi pi-exclamation-triangle",
      acceptClassName: "p-button-danger",
      accept: async () => {
        try {
          await api.put(`user/users/${userId}/deactivate`); // soft delete API
          toast.current.show({
            severity: "success",
            summary: "Deleted",
            detail: "User deleted successfully",
            life: 3000,
          });
          fetchUsers();
        } catch (err) {
          toast.current.show({
            severity: "error",
            summary: "Error",
            detail: "Failed to delete user",
            life: 3000,
          });
        }
      },
      reject: () => {
        toast.current.show({
          severity: "info",
          summary: "Cancelled",
          detail: "User deletion cancelled",
          life: 3000,
        });
      },
    });
  };

  const exportExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(users);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Users");
    const excelBuffer = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "Users.xlsx");
  };

  const actionBodyTemplate = (rowData) => (
    <div className="flex gap-2">
      <Button
        icon="pi pi-pencil"
        rounded
        severity="info"
        onClick={() => handleEdit(rowData)}
        tooltip="Edit"
      />
      <Button
        icon="pi pi-trash"
        rounded
        severity="danger"
        onClick={() => handleDelete(rowData.userId)}
        tooltip="Delete"
      />
    </div>
  );

  const roleBodyTemplate = (rowData) => {
    return (
      <Tag
        value={rowData.role}
        severity={rowData.role === "Admin" ? "success" : "info"}
      />
    );
  };

  return (
    <div className="p-4">
      <Toast ref={toast} />
      <ConfirmDialog />
      <h2 className="text-3xl font-bold mb-2 text-gray-800">
        👥 User Management
      </h2>
      <Divider />

      <div className="flex flex-wrap justify-between items-center gap-3 mb-4">
        <IconField iconPosition="left">
          <InputIcon className="pi pi-search"> </InputIcon>
          <InputText
            value={globalFilter}
            onChange={(e) => setGlobalFilter(e.target.value)}
            placeholder="Search users..."
            className="w-full"
          />
        </IconField>
        <Button
          label=""
          icon="pi pi-download"
          className="p-button-success"
          onClick={exportExcel}
        />
        <Button
          label="Add User"
          icon="pi pi-user-plus"
          className="p-button-primary"
          onClick={handleAdd}
        />
      </div>

      <DataTable
        value={users}
        paginator
        rows={5}
        rowsPerPageOptions={[5, 10, 20]}
        globalFilter={globalFilter}
        responsiveLayout="scroll"
        stripedRows
        showGridlines
        className="shadow-md rounded-xl"
        tableStyle={{ minWidth: "50rem" }}
        emptyMessage="No users found."
      >
        <Column field="empID" header="Employee ID" sortable></Column>
        <Column field="username" header="Username" sortable></Column>
        <Column header="Role" body={roleBodyTemplate} sortable></Column>
        <Column header="Actions" body={actionBodyTemplate}></Column>
      </DataTable>

      <UserFormModal
        visible={modalVisible}
        onHide={() => setModalVisible(false)}
        onSubmit={handleModalSubmit}
        user={editingUser}
      />
    </div>
  );
};

export default UserList;
