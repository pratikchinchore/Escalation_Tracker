// DeveloperLinkStats.js
import React, { useState, useEffect } from "react";
import { Chart } from "primereact/chart";

const DeveloperLinkStats = () => {
  const [barChartData, setBarChartData] = useState({});
  const [barChartOptions, setBarChartOptions] = useState({});

  useEffect(() => {
    const fetchDevStats = async () => {
      try {
        const response = await fetch(
          "http://192.168.16.253:5000/api/dashboard/link-counts"
        );
        const data = await response.json();

        const labels = data.map((entry) => entry.username);
        const csData = data.map((entry) => parseInt(entry.cs_links));
        const surveyData = data.map((entry) => parseInt(entry.survay_links));
        const e_blast_links = data.map((entry) => parseInt(entry.e_blast_links));

        const style = getComputedStyle(document.documentElement);

        setBarChartData({
          labels,
          datasets: [
            {
              label: "CS Links",
              backgroundColor: style.getPropertyValue("--blue-300"),
              borderColor: style.getPropertyValue("--blue-100"),
              data: csData,
              hidden: false,
            },
            {
              label: "Survey Links",
              backgroundColor: style.getPropertyValue("--green-300"),
              borderColor: style.getPropertyValue("--green-100"),
              data: surveyData,
              hidden: true,
            },
            {
              label: "E-Blast Links",
              backgroundColor: style.getPropertyValue("--red-300"),
              borderColor: style.getPropertyValue("--red-100"),
              data: e_blast_links,
              hidden: true,
            },
          ],
        });

        setBarChartOptions({
          indexAxis: "x",
          maintainAspectRatio: false,
          aspectRatio: 0.7,
          plugins: {
            legend: {
              labels: { color: style.getPropertyValue("--text-color") },
            },
          },
          scales: {
            x: {
              ticks: {
                color: style.getPropertyValue("--text-color-secondary"),
                font: { weight: 500 },
              },
              grid: { display: false, drawBorder: false },
            },
            y: {
              ticks: {
                color: style.getPropertyValue("--text-color-secondary"),
              },
              grid: {
                color: style.getPropertyValue("--surface-border"),
                drawBorder: false,
              },
            },
          },
        });
      } catch (err) {
        console.error("Failed to fetch developer link stats:", err);
      }
    };

    fetchDevStats();
  }, []);

  return (
    <div className="mt-5">
      <h5 className="mb-3 ps-5">
        Total Links In {new Date().toLocaleString("default", { month: "long" })}{" "}
        {new Date().getFullYear()}
      </h5>
      <Chart type="bar" data={barChartData} options={barChartOptions} />
    </div>
  );
};

export default DeveloperLinkStats;
