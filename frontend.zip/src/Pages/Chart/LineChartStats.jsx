import React, { useState, useEffect, useContext } from "react";
import { Chart } from "primereact/chart";
import api from "../../axiosConfig";
import { AuthContext } from "../../contexts/AuthContext";

const LineChartStats = ({ dateRange }) => {
  const [chartData, setChartData] = useState({});
  const [chartOptions, setChartOptions] = useState({});
  const [fullDatasets, setFullDatasets] = useState([]);
  const [dayLabels, setDayLabels] = useState([]);
  const { auth } = useContext(AuthContext);

  useEffect(() => {
    if (!auth) return;
    const fetchData = async () => {
      const style = getComputedStyle(document.documentElement);
      const textColor = style.getPropertyValue("--text-color");
      const textColorSecondary = style.getPropertyValue(
        "--text-color-secondary"
      );
      const surfaceBorder = style.getPropertyValue("--surface-border");

      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth();
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
      setDayLabels(days);

      setChartOptions({
        maintainAspectRatio: false,
        aspectRatio: 0.6,
        plugins: {
          legend: { labels: { color: textColor } },
        },
        scales: {
          x: {
            title: { display: true, text: "Day", color: textColor },
            ticks: { color: textColorSecondary },
            grid: { color: surfaceBorder },
          },
          y: {
            title: { display: true, text: "Count", color: textColor },
            ticks: { color: textColorSecondary },
            grid: { color: surfaceBorder },
          },
        },
      });

      try {
        const response = await fetch(
          "http://192.168.16.253:5000/api/dashboard/report"
        );
        const apiData = await response.json();

        const newLinksData = Array(daysInMonth).fill(0);
        const clientsUpdateData = Array(daysInMonth).fill(0);
        const internalErrorData = Array(daysInMonth).fill(0);
        apiData.forEach((entry) => {
          const date = new Date(entry.date);

          // Filter by user role: show all data for Admin, or only own data for PHP-Developer
          const isCurrentMonth =
            date.getMonth() === month && date.getFullYear() === year;
          const isAllowedUser =
            // userInfo?.role === "Admin" || entry.made_by === userInfo?.username;
            auth?.decoded?.role === "Admin" ||
            auth?.decoded?.role === "Tester" ||
            entry.made_by === auth?.decoded?.username;

          if (isCurrentMonth && isAllowedUser) {
            const dayIndex = date.getDate() - 1;
            if (entry.category === "New Link") {
              newLinksData[dayIndex] += entry.count;
            } else if (entry.category === "Client Update") {
              clientsUpdateData[dayIndex] += entry.count;
            } else if (entry.category === "Internal Update") {
              internalErrorData[dayIndex] += entry.count;
            }
          }
        });

        setFullDatasets([
          {
            label: "New Links",
            data: newLinksData,
            fill: true,
            borderColor: style.getPropertyValue("--blue-500"),
            tension: 0.4,
            backgroundColor: "rgba(123, 170, 224, 0.2)",
            hidden: false,
          },
          {
            label: "Clients Update",
            data: clientsUpdateData,
            fill: false,
            tension: 0.4,
            borderColor: style.getPropertyValue("--red-500"),
            hidden: true,
          },
          {
            label: "Internal Update",
            data: internalErrorData,
            fill: false,
            borderDash: [5, 5],
            tension: 0.4,
            borderColor: style.getPropertyValue("--orange-500"),
            hidden: true,
          },
        ]);
      } catch (error) {
        console.error("Error fetching chart data:", error);
      }
    };

    fetchData();
  }, [auth]);

  useEffect(() => {
    if (fullDatasets.length === 0) return;

    let filteredLabels = dayLabels;
    let datasetCopies = fullDatasets.map((ds) => ({ ...ds }));

    if (dateRange && dateRange[0] && dateRange[1]) {
      const startDay = dateRange[0].getDate();
      const endDay = dateRange[1].getDate();
      const min = Math.min(startDay, endDay);
      const max = Math.max(startDay, endDay);

      filteredLabels = dayLabels.filter((day) => day >= min && day <= max);
      datasetCopies = datasetCopies.map((ds) => ({
        ...ds,
        data: ds.data.slice(min - 1, max),
      }));
    }

    setChartData({
      labels: filteredLabels,
      datasets: datasetCopies,
    });
  }, [fullDatasets, dateRange, dayLabels]);

  return (
    <div className="mt-1">
      <Chart
        type="line"
        data={chartData}
        options={chartOptions}
        style={{ height: "400px" }}
      />
    </div>
  );
};

export default LineChartStats;
