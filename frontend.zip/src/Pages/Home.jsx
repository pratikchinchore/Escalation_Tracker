import React from 'react'

const Home = () => {
  return (
    <div>Home TEST</div>
  )
}

export default Home