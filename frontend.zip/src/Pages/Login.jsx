import React, { useState, useRef } from "react";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { useNavigate } from "react-router-dom";
import api from "../axiosConfig";
import { Toast } from "primereact/toast";
import OndirectLogo from "../Images/ondirect-logo.png";
import "./login.css";

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isDefaultPassword, setIsDefaultPassword] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const toast = useRef(null);
  const navigate = useNavigate();

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      toast.current?.show({
        severity: "warn",
        summary: "Required Fields",
        detail: "Both Username and Password are required.",
        life: 3000,
      });
      return;
    }

    try {
      const res = await api.post("auth/login", {
        username,
        password,
      });

      const { token, role, empID, isDefaultPassword } = res.data;

      if (isDefaultPassword) {
        setIsDefaultPassword(true);
        localStorage.setItem("token", token); // Store token even for password update
        return;
      }

      localStorage.setItem("token", token);
      localStorage.setItem("role", role);
      localStorage.setItem("empID", empID);

      toast.current?.show({
        severity: "success",
        summary: "Login Successful",
        detail: `Welcome! Role: ${role}`,
        life: 3000,
      });

      setTimeout(() => {
        navigate("/dashboard");
      }, 100);
    } catch (err) {
      // ✅ check backend error
      const message =
        err.response?.data?.message || "Invalid username or password";

      toast.current?.show({
        severity: "error",
        summary: "Login Failed",
        detail: message,
        life: 3000,
      });

      console.error(err);
    }
  };

  const handlePasswordUpdate = async () => {
    if (newPassword !== confirmPassword) {
      toast.current?.show({
        severity: "warn",
        summary: "Mismatch",
        detail: "Passwords do not match.",
        life: 3000,
      });
      return;
    }

    try {
      await api.post("auth/update-password", {
        username,
        newPassword,
      });

      toast.current?.show({
        severity: "success",
        summary: "Password Updated",
        detail: "Please Login Again",
        life: 4000,
      });

      setTimeout(() => {
        // navigate("/Signup");
        window.location.href = "/Signup";
      }, 1000);
    } catch (err) {
      console.error(err);
      toast.current?.show({
        severity: "error",
        summary: "Update Failed",
        detail: "Try again later.",
        life: 3000,
      });
    }
  };

  return (
    <div className="container-fluid py-5 position-relative">
      {/* Logo in top-left */}
      <div style={{ position: "absolute", top: "80px", left: "30px" }}>
        <img src={OndirectLogo} alt="Company Logo" style={{ height: "60px" }} />
      </div>

      <Toast ref={toast} />

      <div
        className="d-flex justify-content-center align-items-center"
        style={{ minHeight: "100vh" }}
      >
        <div
          className="card w-100 box"
          style={{
            maxWidth: "700px",
            height: isDefaultPassword ? "500px" : "400px",
          }}
          // style={{ maxWidth: "700px", height: "400px" }}
        >
          <div className="row g-0">
            {/* Video Side */}
            <div
              className="col-md-6 d-md-block position-relative"
              style={{ padding: "17px" }}
            >
              <video
                autoPlay
                loop
                muted
                playsInline
                className="img-fluid h-100 w-100 object-fit-cover rounded-end"
                style={{ objectFit: "cover" }}
              >
                <source src="/GIF.mp4" type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            </div>

            {/* Form Side */}
            {/* <div className="col-md-6 p-5 d-flex flex-column justify-content-center align-items-center">
              <h4 className="my-5 signintext text-center fw-bold text-dark">
                SIGN IN
              </h4>

              <div className="w-100 mb-3">
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="pi pi-user"></i>
                  </span>
                  <InputText
                    id="username"
                    type="text"
                    className="form-control custom-placeholder"
                    placeholder="User ID"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                  />
                </div>
              </div>

              <div className="w-100 mb-4">
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="pi pi-lock"></i>
                  </span>
                  <InputText
                    id="password"
                    type="password"
                    className="form-control custom-placeholder"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>

              {isDefaultPassword && (
                <>
                  <div className="w-100 mb-3">
                    <div className="input-group">
                      <span className="input-group-text">
                        <i className="pi pi-lock"></i>
                      </span>
                      <InputText
                        type="password"
                        placeholder="New Password"
                        className="form-control"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="w-100 mb-3">
                    <div className="input-group">
                      <span className="input-group-text">
                        <i className="pi pi-lock"></i>
                      </span>
                      <InputText
                        type="password"
                        placeholder="Confirm Password"
                        className="form-control"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                      />
                    </div>
                  </div>

                  <Button
                    label="Update Password"
                    className="btn btn-success w-100 mb-3"
                    onClick={handlePasswordUpdate}
                  />
                </>
              )}

              {!isDefaultPassword && (
                <Button
                  label="Sign In"
                  icon="pi pi-sign-in"
                  className="btn btn-primary w-100 mb-5 input-group"
                  onClick={handleLogin}
                />
              )}
            </div> */}
            <div className="col-md-6 p-5 d-flex flex-column justify-content-center align-items-center">
              <h4 className="my-5 signintext text-center fw-bold text-dark">
                SIGN IN
              </h4>

              {/* Use a form here */}
              <form
                className="w-100"
                onSubmit={(e) => {
                  e.preventDefault(); // prevent page reload
                  if (isDefaultPassword) {
                    handlePasswordUpdate();
                  } else {
                    handleLogin();
                  }
                }}
              >
                <div className="w-100 mb-3">
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="pi pi-user"></i>
                    </span>
                    <InputText
                      id="username"
                      type="text"
                      className="form-control custom-placeholder"
                      placeholder="User ID"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                    />
                  </div>
                </div>

                <div className="w-100 mb-4">
                  <div className="input-group">
                    <span className="input-group-text">
                      <i className="pi pi-lock"></i>
                    </span>
                    <InputText
                      id="password"
                      type="password"
                      className="form-control custom-placeholder"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                </div>

                {isDefaultPassword && (
                  <>
                    <div className="w-100 mb-3">
                      <div className="input-group">
                        <span className="input-group-text">
                          <i className="pi pi-lock"></i>
                        </span>
                        <InputText
                          type="password"
                          placeholder="New Password"
                          className="form-control"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="w-100 mb-3">
                      <div className="input-group">
                        <span className="input-group-text">
                          <i className="pi pi-lock"></i>
                        </span>
                        <InputText
                          type="password"
                          placeholder="Confirm Password"
                          className="form-control"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                        />
                      </div>
                    </div>
                  </>
                )}

                <Button
                  type="submit" // ✅ key change
                  label={isDefaultPassword ? "Update Password" : "Sign In"}
                  icon={isDefaultPassword ? "" : "pi pi-sign-in"}
                  className={`btn w-100 mb-3 ${
                    isDefaultPassword
                      ? "btn-success"
                      : "btn-primary input-group"
                  }`}
                />
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
