import React, { useEffect, useState, useRef, useContext } from "react";
import api from "../../axiosConfig";
import UpdatesTable from "./UpdatesTable";
import UpdateForm from "./UpdateForm";
import "./styles.css";
import { AuthContext } from "../../contexts/AuthContext";
import {
  DataTable,
  Column,
  Toast,
  Button,
  Dialog,
  ProgressSpinner,
  InputText,
  InputIcon,
  IconField,
  Badge,
  ConfirmDialog,
  confirmDialog,
} from "./../../components/PrimeImports";

const CampaignLinks = () => {
  const toast = useRef(null);
  const { auth } = useContext(AuthContext);
  const userRoles = auth?.decoded?.role;
  const [links, setLinks] = useState([]);
  const [assets, setAssets] = useState([]);
  const [campaignUpdates, setCampaignUpdates] = useState({});
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [showCampaignUpdateModal, setShowCampaignUpdateModal] = useState(false);
  const [expandedRows, setExpandedRows] = useState(null);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [campaignStatus, setCampaignStatus] = useState(false);
  const [description, setDescription] = useState("");
  const [campaignPickTime, setCampaignPickTime] = useState("");
  const [allocationTime, setAllocationTime] = useState("");
  const [internalPublishedTime, setInternalPublishedTime] = useState("");
  const [publishTime, setPublishTime] = useState("");
  const [showAdditionalLink, setShowAdditionalLink] = useState(false);
  const [additionalLink, setAdditionalLink] = useState("");
  const [updateOnAsset, setUpdateOnAsset] = useState(false);
  const [showAssetCommentModal, setShowAssetCommentModal] = useState(false);
  const [assetComments, setAssetComments] = useState({});
  const [globalSearch, setGlobalSearch] = useState("");
  const [pendingCounts, setPendingCounts] = useState({});

  const getCounts = async () => {
    const resCounts = await api.get("/updates/pendingCount");
    const counts = resCounts.data.counts; // { campId: pendingCount }
    setPendingCounts(counts);
    return counts;
  };
  const fetchLinks = async () => {
    try {
      const res = await api.get("/links");
      const linksData = res.data;
      const counts = await getCounts();
      const updatedLinks = linksData.map((link) => ({
        ...link,
        pendingCount: counts[link.id] || 0,
      }));
      setLinks(updatedLinks);
      setLoading(false);
    } catch (err) {
      console.error("Failed to fetch links:", err);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to fetch link data",
        life: 3000,
      });
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLinks();
  }, []);

  const handleRowClick = (e) => {
    const campaign = e.data;
    setSelectedCampaign(campaign);
    setCampaignStatus(campaign.testing_status === "Done");

    api
      .get(`/links/assets/${campaign.id}`)
      .then((res) => {
        setAssets(res.data);
        setModalVisible(true);
      })
      .catch((err) => {
        console.error("Failed to fetch assets:", err);
        toast.current?.show({
          severity: "error",
          summary: "Error",
          detail: "Failed to fetch asset data",
        });
      });
  };

  const hideModal = () => {
    setModalVisible(false);
    setSelectedCampaign(null);
    setAssets([]);
  };

  const formatDateTime = (value) => {
    if (!value) return "";
    const date = new Date(value);
    return date.toLocaleString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const OnlyDateTime = (value) => {
    if (!value) return "";
    const date = new Date(value);
    return date.toLocaleString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  const handleRowToggle = async (e) => {
    setExpandedRows(e.data); // <-- e.data is already the object { [rowId]: true }
    const expandedIds = Object.keys(e.data);
    for (const id of expandedIds) {
      if (!campaignUpdates[id]) {
        try {
          const res = await api.get(`/updates?campaignId=${id}`);
          setCampaignUpdates((prev) => ({ ...prev, [id]: res.data }));
        } catch (err) {
          console.error("Failed to fetch updates:", err);
          toast.current?.show({
            severity: "error",
            summary: "Error",
            detail: "Failed to fetch campaign updates",
          });
          setCampaignUpdates((prev) => ({ ...prev, [id]: [] }));
        }
      }
    }
  };

  const handlePendingCountChange = (campaignId) => {
    fetchLinks();
  };

  const rowExpansionTemplate = (rowData) => (
    <div className="p-3">
      <h5 className="mb-3 text-lg font-semibold text-gray-800">
        Updates for: {rowData.Campaign_Name}
      </h5>
      <UpdatesTable
        campaignId={rowData.id}
        selectedCampaign={rowData}
        onPendingCountChange={handlePendingCountChange}
      />
    </div>
  );

  const deleteLink = (row) => {
    confirmDialog({
      message: (
        <div
          style={{
            textAlign: "center",
            padding: "1.5rem",
            Width: "300px",
            margin: "0 auto",
          }}
        >
          <i
            className="pi pi-exclamation-triangle"
            style={{
              fontSize: "2.5rem",
              color: "#e53935",
              marginBottom: "1rem",
            }}
          ></i>

          <div
            style={{
              fontSize: "1.15rem",
              fontWeight: "500",
              marginBottom: "0.75rem",
            }}
          >
            Are you sure you want to delete this link?
          </div>

          <span
            style={{
              display: "inline-block",
              backgroundColor: "#fdecea",
              padding: "0.5rem 1rem",
              borderRadius: "10px",
              fontWeight: "600",
              color: "#b71c1c",
              fontSize: "1rem",
            }}
          >
            {row.Campaign_Name}
          </span>
        </div>
      ),
      header: (
        <div
          style={{
            textAlign: "center",
            width: "100%",
            fontWeight: "600",
            fontSize: "1.2rem",
          }}
        >
          Confirm Delete
        </div>
      ),
      icon: null, // ❌ disable default small icon
      className: "custom-confirm-dialog", // 👈 attach custom class
      acceptClassName: "p-button-danger p-button-rounded",
      rejectClassName: "p-button-text p-button-secondary p-button-rounded",
      acceptLabel: "Yes, Delete",
      rejectLabel: "Cancel",
      accept: async () => {
        try {
          await api.delete(`/links/${row.id}`);
          setLinks((prev) => prev.filter((item) => item.id !== row.id));
          toast.current?.show({
            severity: "success",
            summary: "Deleted",
            detail: "Link deleted successfully",
            life: 3000,
          });
        } catch (err) {
          console.error("Delete failed:", err);
          toast.current?.show({
            severity: "error",
            summary: "Error",
            detail: "Failed to delete link",
            life: 3000,
          });
        }
      },
    });
  };

  const handleSubmitUpdate = async () => {
    try {
      let tat = "";
      let completionTime = "";
      if (allocationTime && internalPublishedTime) {
        const diff = new Date(internalPublishedTime) - new Date(allocationTime);
        if (!isNaN(diff)) {
          const mins = Math.floor(diff / 60000);
          const hours = Math.floor(mins / 60);
          tat = `${hours}h ${mins % 60}m`;
        }
      }

      if (campaignPickTime && internalPublishedTime) {
        const diff =
          new Date(internalPublishedTime) - new Date(campaignPickTime);
        if (!isNaN(diff)) {
          const mins = Math.floor(diff / 60000);
          const hours = Math.floor(mins / 60);
          completionTime = `${hours}h ${mins % 60}m`;
        }
      }

      const updateRes = await api.post("/updates", {
        camp_id: selectedCampaign.id,
        description,
        allocationTime,
        campaignPickTime,
        internalPublishedTime,
        TAT: tat,
        CT: completionTime,
      });

      const updateId = updateRes.data.id;
      if (updateOnAsset) {
        const assetsWithComments = assets.filter(
          (asset) =>
            assetComments[asset.asset] &&
            assetComments[asset.asset].trim() !== ""
        );

        if (assetsWithComments.length > 0) {
          await Promise.all(
            assetsWithComments.map((asset) =>
              api.post("/update-assets", {
                update_id: updateId,
                asset_title: asset.asset,
                asset_link: asset.link,
                description: assetComments[asset.asset],
              })
            )
          );
        }
      } else {
        // Insert all assets with same main description
        if (description && description.trim() !== "") {
          await Promise.all(
            assets.map((asset) =>
              api.post("/update-assets", {
                update_id: updateId,
                asset_title: asset.asset,
                asset_link: asset.link,
                description,
              })
            )
          );
        }
      }

      if (showAdditionalLink && additionalLink.trim()) {
        await api.post("/links/append-link", {
          camp_id: selectedCampaign.id,
          additionalLink: additionalLink.trim(),
        });
      }
      toast.current?.show({
        severity: "success",
        summary: "Update Added",
        detail: "Campaign update saved successfully.",
      });
      await fetchLinks();
      setShowCampaignUpdateModal(false);
      setDescription("");
      setAllocationTime("");
      setPublishTime("");
      setShowAdditionalLink(false);
      setAdditionalLink("");
      setUpdateOnAsset(false);
      setAssetComments({});
    } catch (err) {
      console.error("Failed to submit update:", err);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to save update",
      });
    }
  };

  const handleStatusChange = async (e) => {
    const newStatus = e.value ? "Done" : "Pending";
    setCampaignStatus(e.value);

    try {
      await api.put(`/links/status/${selectedCampaign?.id}`, {
        status: newStatus,
      });

      toast.current?.show({
        severity: "success",
        summary: "Status Updated",
        detail: `Campaign marked as ${newStatus}`,
      });
      fetchLinks();
    } catch (err) {
      console.error("Failed to update campaign status:", err);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to update campaign status",
      });
    }
  };

  const statusBodyTemplate = (rowData) => {
    const status = rowData.testing_status || "Pending";
    const isDone = status === "Done";
    const campaignCounts = pendingCounts[rowData.id] || {
      pending: 0,
      internalUpdate: 0,
    };

    return (
      <div className="flex items-center justify-center gap-2">
        <span className="p-overlay-badge">
          {isDone ? (
            <Button
              icon="pi pi-check"
              className="custom-status-button done-status"
              disabled
            />
          ) : (
            <Button
              icon="pi pi-clock"
              className="custom-status-button pending-status"
              disabled
            />
          )}
          {campaignCounts.pending > 0 && (
            <Badge value={campaignCounts.pending} severity="danger" />
          )}
        </span>
        {campaignCounts.internalUpdate > 0 && (
          <Badge
            value={campaignCounts.internalUpdate}
            severity="primary"
            className="ml-2"
          />
        )}
      </div>
    );
  };

  return (
    <>
      <Toast ref={toast} />
      <div className="px-3 flex items-baseline w-full">
        <h2 className="font-semibold text-gray-800">All Campaign Links</h2>
        <span className="p-input-icon-left ml-auto" style={{ width: "30rem" }}>
          <IconField iconPosition="left">
            <InputIcon className="pi pi-search"> </InputIcon>
            <InputText
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
              placeholder="Search campaigns and assets..."
              className="w-full"
            />
          </IconField>
        </span>
      </div>

      <div className="card m-2">
        <ConfirmDialog />
        {loading ? (
          <div className="flex justify-content-center p-4">
            <ProgressSpinner />
          </div>
        ) : (
          <DataTable
            value={[...links]
              .reverse()
              .filter((row) =>
                Object.values(row).some((val) =>
                  val
                    ?.toString()
                    .toLowerCase()
                    .includes(globalSearch.toLowerCase())
                )
              )}
            dataKey="id"
            paginator
            rows={5}
            rowsPerPageOptions={[5, 10, 25]}
            stripedRows
            selectionMode="single"
            onRowClick={handleRowClick}
            expandedRows={expandedRows}
            onRowToggle={handleRowToggle}
            rowExpansionTemplate={rowExpansionTemplate}
            tableStyle={{ tableLayout: "fixed", width: "100%" }} 
          >
            <Column expander style={{ width: "4%" }} />
            <Column
              field="internalId"
              header="ID"
              style={{ width: "6%" }}
              bodyClassName="text-center"
              headerClassName="text-center"
            />
            <Column
              field="Campaign_Name"
              header="Campaign Name"
              sortable
              style={{
                width: userRoles?.includes("PHP-Developer") ? "45%" : "25%",
              }}
              headerClassName="text-center"
              bodyClassName="text-center"
            />
            <Column
              field="Country"
              header="Country"
              sortable
              bodyClassName="text-center"
              style={{ width: "10%" }}
            />
            <Column
              field="Campaign_Type"
              header="Type"
              sortable
              bodyClassName="text-center"
              style={{ width: "7%" }}
            />
            <Column
              field="ClientCode"
              header="Client Code"
              style={{ width: "10%" }}
              bodyClassName="text-center"
            />
            <Column
              field="made_by"
              header="Made By"
              sortable
              bodyClassName="text-center"
              style={{ width: "10%" }}
            />

            {userRoles?.includes("Admin") && (
              <Column
                field="allocationTime"
                header="Allocation Time"
                style={{ width: "10%" }}
                body={(rowData) => formatDateTime(rowData.allocationTime)}
              />
            )}

            {userRoles?.includes("PHP-Developer") && (
              <Column
                field="allocationTime"
                header="Date"
                style={{ width: "10%" }}
                body={(rowData) => OnlyDateTime(rowData.allocationTime)}
              />
            )}
            {userRoles?.includes("Admin") && (
              <Column
                field="internalPublishedTime"
                header="Published Time"
                style={{ width: "10%" }}
                body={(rowData) =>
                  formatDateTime(rowData.internalPublishedTime)
                }
              />
            )}
            {userRoles?.includes("Admin") && (
              <Column field="TAT" header="TAT" style={{ width: "5%" }} />
            )}
            {userRoles?.includes("Admin") && (
              <Column field="CT" header="CT" style={{ width: "5%" }} />
            )}

            <Column
              header="STATUS"
              body={statusBodyTemplate}
              bodyClassName="text-center"
              style={{ width: "8%" }}
            />

            {userRoles?.includes("Admin") && (
              <Column
                header="Delete"
                style={{ width: "6%", textAlign: "center" }}
                body={(row) => (
                  <Button
                    icon="pi pi-trash"
                    severity="danger"
                    text
                    rounded
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteLink(row);
                    }}
                  />
                )}
              />
            )}
          </DataTable>
        )}
      </div>

      <Dialog
        header={`Assets for ${selectedCampaign?.Campaign_Name}`}
        visible={modalVisible}
        style={{ width: "80vw" }}
        onHide={hideModal}
        modal
      >
        <Button
          label="Add Update for Campaign"
          className="p-button-danger mb-4"
          onClick={() => setShowCampaignUpdateModal(true)}
        />

        <div className="flex items-center gap-3 mb-4">
          <label className="font-semibold">Campaign Testing Status:</label>

          {campaignStatus ? (
            <Button
              label="Done"
              icon="pi pi-check"
              className="custom-status-button done-status"
              disabled
            />
          ) : userRoles.includes("Tester") ? (
            <Button
              label="Mark as Done"
              icon="pi pi-play"
              className="custom-status-button pending-status"
              onClick={() => handleStatusChange({ value: true })}
            />
          ) : (
            <Button
              label="Pending"
              icon="pi pi-clock"
              className="custom-status-button pending-status"
              disabled
            />
          )}
        </div>

        {assets.length > 0 ? (
          <DataTable
            value={assets.filter((row) =>
              Object.values(row).some((val) =>
                val
                  ?.toString()
                  .toLowerCase()
                  .includes(globalSearch.toLowerCase())
              )
            )}
            rowKey="asset"
            responsiveLayout="stack" 
            style={{ width: "100%" }}
            stripedRows
          >
            <Column field="asset" header="Asset" />
            <Column
              field="link"
              header="Link"
              body={(rowData) => (
                <a href={rowData.link} target="_blank" rel="noreferrer">
                  {rowData.link}
                </a>
              )}
            />
            <Column field="made_by" header="Made By" />
            <Column field="link_type" header="Link Type" />
          </DataTable>
        ) : (
          <p>No assets found.</p>
        )}
      </Dialog>

      <Dialog
        header={`Add Update for ${selectedCampaign?.Campaign_Name}`}
        visible={showCampaignUpdateModal}
        style={{ width: "85vw" }}
        modal
        onHide={() => {
          setShowCampaignUpdateModal(false);
          setDescription("");
          setAllocationTime(null);
          setCampaignPickTime(null);
          setInternalPublishedTime(null);
          setPublishTime(null);
          setShowAdditionalLink(false);
          setAdditionalLink("");
          setUpdateOnAsset(false);
          setAssetComments({});
        }}
      >
        {selectedCampaign && (
          <UpdateForm
            selectedCampaign={selectedCampaign}
            description={description}
            allocationTime={allocationTime}
            campaignPickTime={campaignPickTime}
            internalPublishedTime={internalPublishedTime}
            publishTime={publishTime}
            showAdditionalLink={showAdditionalLink}
            additionalLink={additionalLink}
            setDescription={setDescription}
            setAllocationTime={setAllocationTime}
            setCampaignPickTime={setCampaignPickTime}
            setInternalPublishedTime={setInternalPublishedTime}
            setPublishTime={setPublishTime}
            setShowAdditionalLink={setShowAdditionalLink}
            setAdditionalLink={setAdditionalLink}
            onSubmit={handleSubmitUpdate}
            updateOnAsset={updateOnAsset}
            setUpdateOnAsset={(val) => {
              setUpdateOnAsset(val);
              if (val) {
                setAssetComments({});
                setShowAssetCommentModal(true);
              }
            }}
          />
        )}
      </Dialog>

      <Dialog
        header="Add Comments for Assets"
        visible={showAssetCommentModal}
        style={{ width: "90vw" }}
        modal
        onHide={() => setShowAssetCommentModal(false)}
      >
        {assets.length > 0 ? (
          <DataTable value={assets} rowKey="asset">
            <Column field="asset" header="Asset" />
            <Column
              field="link"
              header="Link"
              body={(rowData) => (
                <a href={rowData.link} target="_blank" rel="noreferrer">
                  {rowData.link}
                </a>
              )}
            />
            <Column
              header="Comment"
              body={(rowData) => (
                <InputText
                  placeholder="Add comment..."
                  defaultValue={assetComments[rowData.asset] || ""}
                  onBlur={(e) =>
                    setAssetComments((prev) => ({
                      ...prev,
                      [rowData.asset]: e.target.value,
                    }))
                  }
                />
              )}
            />
          </DataTable>
        ) : (
          <p>No assets found.</p>
        )}

        <div className="flex justify-end mt-4">
          <Button
            label="Add Comments to Description"
            size="small"
            icon="pi pi-check"
            onClick={() => {
              const commentsText = Object.entries(assetComments)
                .filter(([_, comment]) => comment.trim() !== "")
                .map(([assetKey, comment]) => {
                  const assetObj = assets.find((a) => a.asset === assetKey);
                  const linkValue = assetObj?.link || "N/A";
                  return `Link: ${linkValue} | Comment: ${comment}`;
                })
                .join("\n");
              setDescription(commentsText);
              setShowAssetCommentModal(false);
            }}
          />
        </div>
      </Dialog>
    </>
  );
};

export default CampaignLinks;
