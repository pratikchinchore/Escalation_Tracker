import React, { useState, useEffect } from "react";
import { Button } from "primereact/button";
import { Toolbar } from "primereact/toolbar";
import { Calendar } from "primereact/calendar";
import { ProgressSpinner } from "primereact/progressspinner";
import XLSX from "xlsx-js-style";

import { saveAs } from "file-saver";
import api from "../../axiosConfig";

import DeveloperLinkStats from "../Chart/DeveloperLinkStats";
import LineChartStats from "../Chart/LineChartStats";

const Dashboard = () => {
  const [dateRange, setDateRange] = useState(null);
  const [userInfo, setUserInfo] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await api.get("user/me", {
          headers: {
            Authorization: token,
          },
        });
        setUserInfo(res.data);
      } catch (err) {
        console.error("Failed to fetch user:", err);
      }
    };

    fetchUser();
  }, []);

  const formatDate = (date) => {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const formatDateTime = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, "0");
    const minutes = String(d.getMinutes()).padStart(2, "0");
    return `${day}-${month}-${year} ${hours}:${minutes}`;
  };

  const exportToExcel = async () => {
    if (!dateRange || !dateRange[0] || !dateRange[1]) {
      alert("Please select a date range first.");
      return;
    }

    try {
      const response = await fetch(
        "http://192.168.16.253:5000/api/dashboard/allreport"
      );
      const data = await response.json();

      const start = new Date(dateRange[0]);
      const end = new Date(dateRange[1]);

      const filteredData = data.filter((item) => {
        const itemDate = new Date(item.createdAt);
        const inRange = itemDate >= start && itemDate <= end;

        if (userInfo?.role === "Admin" || userInfo?.role === "Tester") {
          return inRange;
        } else {
          return inRange && item.made_by === userInfo?.username;
        }
      });

      if (filteredData.length === 0) {
        alert("No data found in selected date range.");
        return;
      }
      const stripHtml = (html) => html?.replace(/<[^>]*>/g, "") || "";

      const reportData = filteredData.map((item) => ({
        "Campaign Type": item.Campaign_Type || "",
        "Client Code": item.ClientCode || "",
        "Internal ID": item.internalId || "",
        "Work Type": item.link_type || "",
        "Campaign Date": formatDate(item.createdAt) || "",
        "Campaign Name": item.Campaign_Name || "",
        "Asset Title": item.asset || "",
        Link: item.link || "",
        "Allocation Time": formatDateTime(item.allocationTime) || "",
        "Published Time": formatDateTime(item.internalPublishedTime) || "",
        TAT: item.TAT || "",
        Comment: stripHtml(item.Comment),
        "Made By": item.made_by || "",
      }));

      // Create worksheet
      const worksheet = XLSX.utils.json_to_sheet(reportData, { origin: "A1" });

      // Get column headers
      const headerKeys = Object.keys(reportData[0]);

      // Apply header styling
      headerKeys.forEach((key, index) => {
        const cellAddress = XLSX.utils.encode_cell({ r: 0, c: index }); // Row 0, column index
        if (!worksheet[cellAddress]) return;
        worksheet[cellAddress].s = {
          font: { bold: true, color: { rgb: "FFFFFF" } }, // white bold
          fill: { fgColor: { rgb: "4F81BD" } }, // blue background
          alignment: { horizontal: "center", vertical: "center" },
          border: {
            top: { style: "thin", color: { rgb: "000000" } },
            bottom: { style: "thin", color: { rgb: "000000" } },
            left: { style: "thin", color: { rgb: "000000" } },
            right: { style: "thin", color: { rgb: "000000" } },
          },
        };
      });

      // Apply border to all cells
      const range = XLSX.utils.decode_range(worksheet["!ref"]);
      for (let R = range.s.r; R <= range.e.r; R++) {
        for (let C = range.s.c; C <= range.e.c; C++) {
          const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
          if (!worksheet[cellAddress]) continue;
          worksheet[cellAddress].s = {
            ...worksheet[cellAddress].s,
            border: {
              top: { style: "thin", color: { rgb: "000000" } },
              bottom: { style: "thin", color: { rgb: "000000" } },
              left: { style: "thin", color: { rgb: "000000" } },
              right: { style: "thin", color: { rgb: "000000" } },
            },
          };
        }
      }

      worksheet["!cols"] = [
        { wch: 13 },
        { wch: 10 },
        { wch: 10 },
        { wch: 15 },
        { wch: 15 },
        { wch: 30 },
        { wch: 25 },
        { wch: 25 },
        { wch: 15 },
        { wch: 15 },
        { wch: 10 },
        { wch: 30 },
        { wch: 10 },
      ];
      // Create workbook and append sheet
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Report");

      // Export
      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });

      const blob = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      saveAs(blob, `Report_${formatDate(start)}_to_${formatDate(end)}.xlsx`);
      setDateRange(null);
    } catch (error) {
      console.error("Error exporting to Excel:", error);
      alert("Failed to export. Check console for more details.");
    }
  };

  const leftContent = (
    <div className="flex flex-column md:flex-row md:align-items-center gap-3">
      <h3 className="m-0">Dashboard</h3>
    </div>
  );

  const rightContent = (
    <>
      <div className="flex flex-column md:flex-row md:align-items-center gap-3 me-4">
        <Calendar
          value={dateRange}
          onChange={(e) => setDateRange(e.value)}
          selectionMode="range"
          readOnlyInput
          placeholder="Date Range"
          showIcon
        />
      </div>
      <div className="flex flex-wrap align-items-center gap-3">
        <Button
          label="Export"
          icon="pi pi-file-excel"
          severity="success"
          onClick={exportToExcel}
          disabled={!userInfo} // Wait for user info to load
        />
      </div>
    </>
  );

  return (
    <div className="card">
      <Toolbar
        left={leftContent}
        right={rightContent}
        className="mb-4 flex-wrap"
      />
      <LineChartStats dateRange={dateRange} />
      <DeveloperLinkStats />
    </div>
  );
};

export default Dashboard;
