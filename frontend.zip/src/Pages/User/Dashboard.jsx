import React, { useState, useEffect, useContext } from "react";
import { Button } from "primereact/button";
import { Toolbar } from "primereact/toolbar";
import { Calendar } from "primereact/calendar";
import * as XLSX from "xlsx-js-style";
import { saveAs } from "file-saver";
import api from "../../axiosConfig";
import DeveloperLinkStats from "../Chart/DeveloperLinkStats";
import LineChartStats from "../Chart/LineChartStats";
import { AuthContext } from "../../contexts/AuthContext";
import {format} from "date-fns";

const Dashboard = () => {
  const [dateRange, setDateRange] = useState(null);
  const [month, setMonth] = useState(new Date());
  const { auth } = useContext(AuthContext);

  const [totals, setTotals] = useState({
    csLinks: 0,
    surveyLinks: 0,
    links: 0,
    clientUpdates: 0,
    internalErrors: 0,
  });

  // ✅ Fetch monthly totals
  useEffect(() => {
    if (!auth) return;

    const fetchTotals = async () => {
      try {
        const response = await fetch(
          "http://192.168.16.253:5000/api/dashboard/report"
        );
        const data = await response.json();

        const m = month.getMonth();
        const y = month.getFullYear();

        let links = 0,
          clientUpdates = 0,
          internalErrors = 0,
          csLinks = 0,
          surveyLinks = 0;

        data.forEach((entry) => {
          const d = new Date(entry.date);
          const isThisMonth = d.getMonth() === m && d.getFullYear() === y;

          const isAllowedUser =
            auth?.decoded?.role === "Admin" ||
            auth?.decoded?.role === "Tester" ||
            entry.made_by === auth?.decoded?.username;

          if (isThisMonth && isAllowedUser) {
            if (entry.category === "New Link") {
              links += entry.count; // ✅ keep total New Link logic
              if (
                entry.campaign_group === "CS/E-Blast" ||
                entry.campaign_group === "CS"
              ) {
                csLinks += entry.count;
              }
              if (entry.campaign_group === "Survey") {
                surveyLinks += entry.count;
              }
            }
            if (entry.category === "Client Update")
              clientUpdates += entry.count;
            if (entry.category === "Internal Update")
              internalErrors += entry.count;
          }
        });

        setTotals({
          links,
          csLinks,
          surveyLinks,
          clientUpdates,
          internalErrors,
        });
      } catch (err) {
        console.error("Error fetching totals:", err);
      }
    };

    fetchTotals();
  }, [month, auth]);

  const formatDate = (date) => {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const formatDateTime = (date) => {
    if (!date) return "";
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0");
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = d.getFullYear();
    const hours = String(d.getHours()).padStart(2, "0");
    const minutes = String(d.getMinutes()).padStart(2, "0");
    return `${day}-${month}-${year} ${hours}:${minutes}`;
  };

  const exportToExcel = async () => {
    if (!dateRange || !dateRange[0] || !dateRange[1]) {
      alert("Please select a date range first.");
      return;
    }

    try {
      const response = await fetch(
        "http://192.168.16.253:5000/api/dashboard/allreport"
      );
      const data = await response.json();

      const start = new Date(dateRange[0]);
      const end = new Date(dateRange[1]);

      const filteredData = data.filter((item) => {
        const itemDate = new Date(item.createdAt);
        const inRange = itemDate >= start && itemDate <= end;

        if (
          auth?.decoded?.role === "Admin" ||
          auth?.decoded?.role === "Tester"
        ) {
          return inRange;
        } else {
          return inRange && item.made_by === auth?.decoded?.username;
        }
      });

      if (filteredData.length === 0) {
        alert("No data found in selected date range.");
        return;
      }

      const stripHtml = (html) => html?.replace(/<[^>]*>/g, "") || "";

      const reportData = filteredData.map((item) => ({
        "Campaign Type": item.Campaign_Type || "",
        "Client Code": item.ClientCode || "",
        "Internal ID": item.internalId || "",
        "Work Type": item.link_type || "",
        "Campaign Date": formatDate(item.createdAt) || "",
        "Campaign Name": item.Campaign_Name || "",
        "Asset Title": item.asset || "",
        Link: item.link || "",
        "Allocation Time": formatDateTime(item.allocationTime) || "",
        "Published Time": formatDateTime(item.internalPublishedTime) || "",
        TAT: item.TAT || "",
        Comment: stripHtml(item.Comment),
        "Made By": item.made_by || "",
      }));

      const worksheet = XLSX.utils.json_to_sheet(reportData, { origin: "A1" });

      // Header styling
      const headerKeys = Object.keys(reportData[0]);
      headerKeys.forEach((key, index) => {
        const cellAddress = XLSX.utils.encode_cell({ r: 0, c: index });
        if (!worksheet[cellAddress]) return;
        worksheet[cellAddress].s = {
          font: { bold: true, color: { rgb: "FFFFFF" } },
          fill: { fgColor: { rgb: "4F81BD" } },
          alignment: { horizontal: "center", vertical: "center" },
          border: {
            top: { style: "thin", color: { rgb: "000000" } },
            bottom: { style: "thin", color: { rgb: "000000" } },
            left: { style: "thin", color: { rgb: "000000" } },
            right: { style: "thin", color: { rgb: "000000" } },
          },
        };
      });

      // Apply border to all cells
      const range = XLSX.utils.decode_range(worksheet["!ref"]);
      for (let R = range.s.r; R <= range.e.r; R++) {
        for (let C = range.s.c; C <= range.e.c; C++) {
          const cellAddress = XLSX.utils.encode_cell({ r: R, c: C });
          if (!worksheet[cellAddress]) continue;
          worksheet[cellAddress].s = {
            ...worksheet[cellAddress].s,
            border: {
              top: { style: "thin", color: { rgb: "000000" } },
              bottom: { style: "thin", color: { rgb: "000000" } },
              left: { style: "thin", color: { rgb: "000000" } },
              right: { style: "thin", color: { rgb: "000000" } },
            },
          };
        }
      }

      worksheet["!cols"] = [
        { wch: 13 },
        { wch: 10 },
        { wch: 10 },
        { wch: 15 },
        { wch: 15 },
        { wch: 30 },
        { wch: 25 },
        { wch: 25 },
        { wch: 15 },
        { wch: 15 },
        { wch: 10 },
        { wch: 30 },
        { wch: 10 },
      ];

      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Report");

      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
      const blob = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      saveAs(blob, `Report_${formatDate(start)}_to_${formatDate(end)}.xlsx`);
      setDateRange(null);
    } catch (error) {
      console.error("Error exporting to Excel:", error);
      alert("Failed to export. Check console for more details.");
    }
  };

  return (
    <div>
      {" "}
      {/* <h3 className="mb-2 text-primary text-center font-bold text-2xl relative inline-block">
  📊 Dashboard
</h3> */}
      <div className="card">
        <Toolbar
          className="mb-2 border-none bg-transparent"
          style={{ padding: "0.5rem", display: "flex", alignItems: "stretch" }}
          left={
            // === Links Count Card (Left) ===
            <div className="p-2 border-round-lg shadow-2 bg-white flex flex-column w-full h-full">
              {/* Header Row */}
              <div className="flex align-items-center justify-content-between mb-2">
                <h4 className="m-0 text-900 font-medium flex align-items-center gap-2">
                  🔗 Links Count
                </h4>
                <Calendar
                  value={month}
                  onChange={(e) => setMonth(e.value)}
                  view="month"
                  dateFormat="mm/yy" // keep internal handling
                  className="w-8rem px-3"
                />
                {/* Display formatted value */}
                {/* {month && (
                  <span className="ml-2">
                    {format(month, "MMM-yyyy")}  
                  </span>
                )} */}
              </div>

              {/* Stats */}
              <div className="flex flex-wrap gap-2 justify-content-center mt-auto">
                <div className="px-2 py-1 border-round-lg bg-blue-50 text-blue-600 shadow-1 min-w-5rem text-center">
                  <small className="text-sm">CS Links</small>
                  <div className="font-bold text-base">{totals.csLinks}</div>
                </div>
                <div className="px-2 py-1 border-round-lg bg-indigo-50 text-indigo-600 shadow-1 min-w-5rem text-center">
                  <small className="text-sm">Survey Links</small>
                  <div className="font-bold text-base">
                    {totals.surveyLinks}
                  </div>
                </div>
                <div className="px-2 py-1 border-round-lg bg-red-50 text-red-600 shadow-1 min-w-5rem text-center">
                  <small className="text-sm">Client Update</small>
                  <div className="font-bold text-base">
                    {totals.clientUpdates}
                  </div>
                </div>
                <div className="px-2 py-1 border-round-lg bg-orange-50 text-orange-600 shadow-1 min-w-5rem text-center">
                  <small className="text-sm">Internal Update</small>
                  <div className="font-bold text-base">
                    {totals.internalErrors}
                  </div>
                </div>
              </div>
            </div>
          }
          right={
            // === Export Report Card (Right) ===
            <div className="p-2 border-round-lg shadow-2 bg-white flex flex-column w-full h-full">
              <div className="flex align-items-center justify-content-center mb-1 mt-2 w-full">
                <h4 className="m-0 text-900 font-medium text-center flex align-items-center gap-2">
                  📥 Export Report
                </h4>
              </div>

              <div className="flex align-items-center gap-2 justify-content-end mt-auto">
                <Calendar
                  value={dateRange}
                  onChange={(e) => setDateRange(e.value)}
                  selectionMode="range"
                  readOnlyInput
                  placeholder="Date Range"
                  showIcon
                  className="w-12rem text-xs py-1 px-2"
                  panelClassName="text-sm"
                />
                <Button
                  icon="pi pi-file-excel"
                  severity="success"
                  // className="p-button-sm p-button-rounded p-button-outlined p-button-danger"
                  className="p-button-rounded p-button-sm shadow-1"
                  onClick={exportToExcel}
                  disabled={!auth}
                  tooltip="Export to Excel"
                  tooltipOptions={{ position: "top" }}
                />
              </div>
            </div>
          }
        />

        <LineChartStats dateRange={dateRange} />
        <DeveloperLinkStats />
      </div>
    </div>
  );
};

export default Dashboard;
