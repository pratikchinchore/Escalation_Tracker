import React, { useState } from "react";
import { Controller, useWatch } from "react-hook-form";
import classNames from "classnames";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";

export default function DateTimeInput({
  name,
  control,
  errors,
  rules,
  placeholder = "dd-mm-yyyy hh:mm",
}) {
  const [customError, setCustomError] = useState("");

  // Watch values to validate against each other
  const allocation = useWatch({ control, name: "allocationTime" });
  const campaignPick = useWatch({ control, name: "campaignPickTime" });
  const internalPub = useWatch({ control, name: "internalPublishedTime" });

  // Validation logic
  const isInvalidDateTime = (date) => {
    if (!date) return false;

    if (name === "allocationTime" && campaignPick) {
      return date.isAfter(dayjs(campaignPick));
    }
    if (name === "campaignPickTime") {
      if (allocation && date.isBefore(dayjs(allocation))) return true;
      if (internalPub && date.isAfter(dayjs(internalPub))) return true;
    }
    if (name === "internalPublishedTime" && campaignPick) {
      return date.isBefore(dayjs(campaignPick));
    }
    return false;
  };

  const getErrorMessage = () => {
    if (errors?.[name]?.message) return errors[name].message;
    return customError;
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field }) => (
          <DateTimePicker
            {...field}
            value={field.value ? dayjs(field.value) : null} // keep as dayjs
            onChange={(date) => {
              field.onChange(date || null); // store as dayjs object

              if (isInvalidDateTime(date)) {
                setCustomError(
                  name === "allocationTime"
                    ? "Must be before Campaign Pick Time"
                    : name === "campaignPickTime"
                    ? "Must be after Allocation & before Internal Publish"
                    : name === "internalPublishedTime"
                    ? "Must be after Campaign Pick Time"
                    : "Invalid date/time"
                );
              } else {
                setCustomError("");
              }
            }}
            format="DD-MM-YYYY HH:mm"
            ampm={true} // keep 24-hour mode
            minutesStep={1}
            timeSteps={{ minutes: 1 }}
            slotProps={{
              textField: {
                placeholder,
                className: classNames("pinput", {
                  "p-invalid": errors?.[name] || !!customError,
                }),
                error: !!errors?.[name] || !!customError,
                helperText: (
                  <span style={{ color: "red" }}>{getErrorMessage()}</span>
                ),
              },
            }}
          />
        )}
      />
    </LocalizationProvider>
  );
}
