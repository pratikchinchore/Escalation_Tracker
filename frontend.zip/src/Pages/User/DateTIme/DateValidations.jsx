// helpers/dateValidations.js
export const validateDateOrder = (value, fieldName, watch) => {
  const allocation = watch("allocationTime");
  const campaignPick = watch("campaignPickTime");
  const internalPub = watch("internalPublishedTime");

  switch (fieldName) {
    case "allocationTime":
      if (campaignPick && new Date(value) >= new Date(campaignPick)) {
        return "Allocation Time must be before Campaign Pick Time";
      }
      break;

    case "campaignPickTime":
      if (allocation && new Date(value) <= new Date(allocation)) {
        return "Campaign Pick Time must be after Allocation Time";
      }
      if (internalPub && new Date(value) >= new Date(internalPub)) {
        return "Campaign Pick Time must be before Internal Published Time";
      }
      break;

    case "internalPublishedTime":
      if (campaignPick && new Date(value) <= new Date(campaignPick)) {
        return "Internal Published Time must be after Campaign Pick Time";
      }
      break;

    default:
      break;
  }
  return true;
};
