import React, { useEffect, useState, useRef } from "react";
import { useForm, Controller, useWatch } from "react-hook-form";
import { Dialog } from "primereact/dialog";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText, InputTextarea, Dropdown, Button, Toast } from "primereact";
import { classNames } from "primereact/utils";
import "./styles.css";
import DateTimeInput from "./DateTIme/DateTimeInput";
import { validateDateOrder } from "./DateTIme/DateValidations";
import { Tooltip } from "primereact/tooltip";

const Campaign_Type = [
  { label: "CS", value: "CS" },
  { label: "Survey", value: "Survey" },
  { label: "E-Blast", value: "E-Blast" },
];

const Country = [
  { label: "EU", value: "EU" },
  { label: "Non-EU", value: "Non-EU" },
  { label: "Both", value: "Both" },
];

const Linkform = () => {
  const {
    control,
    handleSubmit,
    setError,
    clearErrors,
    setValue,
    formState: { errors },
    reset,
    watch,
  } = useForm({
    defaultValues: {
      Campaign_Name: "",
      internalId: "",
      // include other fields as well
    },
  });

  const [showModal, setShowModal] = useState(false);
  const [clientCodeMap, setClientCodeMap] = useState({});
  const [clientCodeOptions, setClientCodeOptions] = useState([]);
  const [phantomOptions, setPhantomOptions] = useState([]);
  const [selectedClientCode, setSelectedClientCode] = useState(null);
  const toast = useRef(null);
  const selectedCampaignType = watch("Campaign_Type");
  const publishTime = useWatch({ control, name: "publishTime" });
  const allocationTime = useWatch({ control, name: "allocationTime" });
  const campaignPickTime = useWatch({ control, name: "campaignPickTime" });
  const [parsedDescription, setParsedDescription] = useState([]);

  const internalPublishedTime = useWatch({
    control,
    name: "internalPublishedTime",
  });

  useEffect(() => {
    fetch("/clientCodes.json")
      .then((res) => res.json())
      .then(setClientCodeMap)
      .catch((err) => console.error("Failed to load client codes:", err));

    fetch("/phantomOptions.json")
      .then((res) => res.json())
      .then(setPhantomOptions)
      .catch((err) => console.error("Failed to load phantom options:", err));
  }, []);

  useEffect(() => {
    if (selectedCampaignType && clientCodeMap[selectedCampaignType]) {
      setClientCodeOptions(clientCodeMap[selectedCampaignType]);
    } else {
      setClientCodeOptions([]);
    }
  }, [selectedCampaignType, clientCodeMap]);

  const calculateTAT = () => {
    if (!allocationTime || !internalPublishedTime) return "";
    const diff = new Date(internalPublishedTime) - new Date(allocationTime);
    if (isNaN(diff)) return "";
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    return `${hours}h ${mins % 60}m`;
  };

  const calculateCompletionTime = () => {
    if (!campaignPickTime || !internalPublishedTime) return "";
    const diff = new Date(internalPublishedTime) - new Date(campaignPickTime);
    if (isNaN(diff)) return "";
    const mins = Math.floor(diff / 60000);
    const hours = Math.floor(mins / 60);
    return `${hours}h ${mins % 60}m`;
  };

  const onSubmit = (data) => {
    if (data.ClientCode === "PHANTOM" && data.phantomOption) {
      data.ClientCode += ` - ${data.phantomOption}`;
    }
    delete data.phantomOption;

    const tat = calculateTAT();
    const completionTime = calculateCompletionTime();

    data.TAT = tat;
    data.CT = completionTime;

    fetch("http://192.168.16.253:5000/api/links/createLink", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify(data),
    })
      .then((res) => res.json())
      .then(() => {
        toast.current.show({
          severity: "success",
          summary: "Success",
          detail: "Submitted successfully!",
          life: 3000,
        });
        reset();
        setSelectedClientCode(null);
        setParsedDescription([]);
      })
      .catch((err) => {
        console.error("Submit error:", err);
        alert("Something went wrong");
      });
  };

  const checkDuplicates = async (linksArray) => {
    try {
      const response = await fetch(
        "http://192.168.16.253:5000/api/links/check-duplicates",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ links: linksArray }),
        }
      );

      const data = await response.json();
      return data.duplicates || [];
    } catch (err) {
      console.error("Error checking duplicates:", err);
      return [];
    }
  };

  return (
    <>
      <div className="card p-4" style={{ maxWidth: 1100, margin: "auto" }}>
        <Toast ref={toast} />

        <form onSubmit={handleSubmit(onSubmit)} className="p-fluid grid">
          {/* Campaign Name */}
          <div className="field col-8">
            <label className={"labletext"}>Campaign Name</label>
            <Controller
              name="Campaign_Name"
              control={control}
              rules={{ required: "Required" }}
              render={({ field }) => (
                <InputText
                  {...field}
                  className={classNames("pinput", {
                    "p-invalid": errors.Campaign_Name,
                  })}
                />
              )}
            />
            {errors.Campaign_Name && (
              <small className="p-error">{errors.Campaign_Name.message}</small>
            )}
          </div>

          {/* Internal ID */}
          <div className="field col-4">
            <label className={"labletext"}>Campaign ID</label>
            <Controller
              name="internalId"
              control={control}
              render={({ field }) => (
                <InputText
                  {...field}
                  className={classNames("pinput", {
                    "p-invalid": errors.internalId,
                  })}
                />
              )}
            />
            {errors.internalId && (
              <small className="p-error">{errors.internalId.message}</small>
            )}
          </div>
          {/* Campaign Type */}

          <div className="field col-3">
            <label className={"labletext"}>Campaign Type</label>
            <Controller
              name="Campaign_Type"
              control={control}
              rules={{ required: "Required" }}
              render={({ field }) => (
                <Dropdown
                  {...field}
                  options={Campaign_Type}
                  placeholder="Select Campaign Type"
                  className={classNames({
                    "p-invalid": errors.Campaign_Type,
                  })}
                />
              )}
            />
            {errors.Campaign_Type && (
              <small className="p-error">{errors.Campaign_Type.message}</small>
            )}
          </div>

          {/* Client Code */}
          <div className="field col-3">
            <label className={"labletext"}>Client Code</label>
            <Controller
              name="ClientCode"
              control={control}
              rules={{ required: "Required" }}
              render={({ field }) => (
                <Dropdown
                  {...field}
                  options={clientCodeOptions}
                  placeholder={
                    selectedCampaignType
                      ? "Select Client Code"
                      : "Select Campaign Type first"
                  }
                  onChange={(e) => {
                    field.onChange(e.value);
                    setSelectedClientCode(e.value);
                  }}
                  disabled={!selectedCampaignType}
                  className={classNames({ "p-invalid": errors.ClientCode })}
                />
              )}
            />
            {errors.ClientCode && (
              <small className="p-error">{errors.ClientCode.message}</small>
            )}
          </div>

          {/* Phantom Option */}
          {selectedClientCode === "PHANTOM" && (
            <div className="field col-3">
              <label className={"labletext"}>Sub Category</label>
              <Controller
                name="phantomOption"
                control={control}
                rules={{ required: "Sub Type is required" }}
                render={({ field }) => (
                  <Dropdown
                    {...field}
                    options={phantomOptions}
                    placeholder="Select Sub Type"
                    className={classNames({
                      "p-invalid": errors.phantomOption,
                    })}
                  />
                )}
              />
              {errors.phantomOption && (
                <small className="p-error">
                  {errors.phantomOption.message}
                </small>
              )}
            </div>
          )}
          <div className="field col-3">
            <label className={"labletext"}>Country</label>
            <Controller
              name="Country"
              control={control}
              rules={{ required: "Required" }}
              render={({ field }) => (
                <Dropdown
                  {...field}
                  options={Country}
                  placeholder="Select Country"
                  className={classNames({ "p-invalid": errors.Country })}
                />
              )}
            />
            {errors.Country && (
              <small className="p-error">{errors.Country.message}</small>
            )}
          </div>

          {/* Allocation Time */}
          <div className="field row rowpad">
            <div className="field col-3">
              <label className="labletext">Allocation Time</label>
              <DateTimeInput
                name="allocationTime"
                control={control}
                watch={watch}
                errors={errors}
                rules={{
                  required: "Required",
                  validate: (value) =>
                    validateDateOrder(value, "allocationTime", watch),
                }}
              />
            </div>

            <div className="field col-3">
              <label className="labletext">Campaign Pick Time</label>
              <DateTimeInput
                name="campaignPickTime"
                control={control}
                errors={errors}
                watch={watch}
                rules={{
                  required: "Required",
                  validate: (value) =>
                    validateDateOrder(value, "campaignPickTime", watch),
                }}
              />
            </div>

            <div className="field col-3">
              <label className="labletext">Internal Published Time</label>
              <DateTimeInput
                name="internalPublishedTime"
                control={control}
                errors={errors}
                watch={watch}
                rules={{
                  required: "Required",
                  validate: (value) =>
                    validateDateOrder(value, "internalPublishedTime", watch),
                }}
              />
            </div>
            {/* TAT */}
            <div className="field col-3">
              <label className={"labletext"}>TAT / CT</label>
              <InputText
                className={classNames("pinput")}
                value={`${calculateTAT()} / ${calculateCompletionTime()}`}
                disabled
              />
            </div>
          </div>
          {/* Description */}
          <div className="field col-12 colpad">
            <label className={"labletext"}>
              Paste Excel Table as shown below (2 columns: Title and Link)
            </label>

            <Controller
              name="description"
              control={control}
              rules={{ required: "Required" }}
              render={({ field }) => (
                <div style={{ position: "relative" }}>
                  <InputTextarea
                    {...field}
                    rows={4}
                    style={{
                      zIndex: 2,
                      backgroundColor: "transparent",
                      color: field.value ? "#000" : "transparent",
                    }}
                    onPaste={async (e) => {
                      e.preventDefault(); // Prevent default paste

                      const pastedText = e.clipboardData.getData("text");
                      const rawRows = pastedText.split("\n");

                      // Parse rows
                      const rows = rawRows
                        .map((row) =>
                          row.split("\t").map((cell) => cell.trim())
                        )
                        .filter(
                          (cells) =>
                            cells.length > 0 &&
                            cells.some((cell) => cell !== "")
                        );

                      // Validate columns
                      const invalidRow = rows.find(
                        (cells) => cells.length !== 2
                      );
                      if (invalidRow) {
                        setParsedDescription([]);
                        setShowModal(false);
                        setError("description", {
                          type: "manual",
                          message:
                            "Each row must contain exactly 2 columns: Asset Title and Link.",
                        });
                        return;
                      }

                      // Extract only links (second column)
                      const linksOnly = rows.map((r) => r[1]);

                      try {
                        const response = await fetch(
                          "http://192.168.16.253:5000/api/links/check-duplicates",
                          {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ links: linksOnly }),
                          }
                        );

                        const data = await response.json();
                        const duplicates = data.duplicates || []; // now contains objects

                        // Map duplicates by link for quick lookup
                        const duplicateMap = {};
                        duplicates.forEach((d) => {
                          duplicateMap[d.link] = {
                            campaign_name: d.Campaign_Name,
                            made_by: d.made_by,
                          };
                        });

                        // Store parsed rows with duplicate flag + metadata
                        setParsedDescription(
                          rows.map((r) => ({
                            title: r[0],
                            link: r[1],
                            isDuplicate: !!duplicateMap[r[1]],
                            duplicateMeta: duplicateMap[r[1]] || null,
                          }))
                        );

                        field.onChange(pastedText);
                        clearErrors("description");
                        setShowModal(true);
                      } catch (err) {
                        console.error("Error checking duplicates:", err);
                        setError("description", {
                          type: "manual",
                          message:
                            "Failed to check duplicates. Please try again.",
                        });
                      }
                    }}
                    onChange={(e) => {
                      field.onChange(e);
                    }}
                  />
                  {!field.value && (
                    <img
                      src="/Excel-Placeholder.jpg"
                      alt="Example placeholder"
                      style={{
                        position: "absolute",
                        top: "26px",
                        left: "12px",
                        right: "12px",
                        opacity: 0.6,
                        pointerEvents: "none",
                        zIndex: 1,
                        objectFit: "contain",
                      }}
                    />
                  )}
                </div>
              )}
            />

            {/* Modal for table preview */}
            <Dialog
              header="Live Preview"
              visible={showModal}
              style={{ width: "80vw", maxHeight: "80vh" }}
              onHide={() => {
                setShowModal(false);
                setParsedDescription([]);

                // clear input ONLY if duplicates exist
                const hasDuplicates = parsedDescription.some(
                  (row) => row.isDuplicate
                );
                if (hasDuplicates) {
                  setValue("description", "");
                }
              }}
              draggable={false}
              resizable={false}
            >
              <div className="overflow-auto" style={{ maxHeight: "60vh" }}>
                {parsedDescription.length > 0 && (
                  <div className="mt-3">
                    <DataTable
                      value={parsedDescription}
                      scrollable
                      scrollHeight="300px"
                      size="small"
                      rowClassName={(rowData) =>
                        rowData.isDuplicate ? "bg-light-danger" : ""
                      }
                    >
                      <Column header="Asset Title" field="title" />
                      <Column
                        header="Link"
                        body={(rowData) => (
                          <span
                            className={
                              rowData.isDuplicate ? "text-danger fw-bold" : ""
                            }
                            data-pr-tooltip={
                              rowData.isDuplicate
                                ? `Campaign Name: ${
                                    rowData.duplicateMeta?.campaign_name || "-"
                                  }\n\nMade By: ${
                                    rowData.duplicateMeta?.made_by || "-"
                                  }`
                                : ""
                            }
                            data-pr-position="top"
                          >
                            {rowData.link}
                          </span>
                        )}
                      />
                    </DataTable>

                    {/* Tooltip initializer */}
                    <Tooltip
                      target="[data-pr-tooltip]"
                      className="custom-tooltip"
                      escape={false}
                    />
                  </div>
                )}
              </div>
            </Dialog>

            {/* Show validation error */}
            {errors.description && (
              <small className="p-error">{errors.description.message}</small>
            )}
          </div>

          {/* Comment */}
          <div className="field col-12 colpad">
            <label className={"labletext"}>Comment</label>
            <Controller
              name="Comment"
              control={control}
              render={({ field }) => (
                <InputTextarea {...field} rows={1} placeholder="If Any..." />
              )}
            />
          </div>

          {/* Submit Button */}
          <div className="col-3 mt-1">
            <Button label="Add Links" type="submit" className="w-full rounded" />
          </div>
        </form>
      </div>
    </>
  );
};

export default Linkform;
