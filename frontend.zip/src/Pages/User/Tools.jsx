import React from 'react';

const Tools = () => {
  return (
    <div style={{ height: '100vh' }}>
      <iframe
        src="http://192.168.1.14:9090/storm_design_template_preview/"
        title="Storm Design Preview"
        width="100%"
        height="100%"
        style={{ border: 'none' }}
      />
    </div>
  );
};

export default Tools;
