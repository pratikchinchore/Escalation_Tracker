import { useEffect, useState } from "react";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import { InputSwitch } from "primereact/inputswitch";
import { Button } from "primereact/button";
import { Editor } from "primereact/editor";
import { useForm, FormProvider } from "react-hook-form";
import "./styles.css";
import DateTimeInput from "./DateTIme/DateTimeInput";
import DOMPurify from "dompurify";

const UpdateForm = ({
  selectedCampaign,
  description,
  allocationTime,
  campaignPickTime,
  internalPublishedTime,
  showAdditionalLink,
  additionalLink,
  setDescription,
  setAllocationTime,
  setCampaignPickTime,
  setInternalPublishedTime,
  setShowAdditionalLink,
  setAdditionalLink,
  onSubmit,
  updateOnAsset,
  setUpdateOnAsset,
}) => {
  const [tat, setTAT] = useState("");
  const [completionTime, setCompletionTime] = useState("");
  const [errors, setErrors] = useState({});
  const userRoles = localStorage.getItem("role");

  // ✅ react-hook-form context (required by DateTimeInput)
  const methods = useForm({
    defaultValues: {
      allocationTime: allocationTime ? new Date(allocationTime) : null,
      campaignPickTime: campaignPickTime ? new Date(campaignPickTime) : null,
      internalPublishedTime: internalPublishedTime
        ? new Date(internalPublishedTime)
        : null,
    },
  });

  // ✅ Sync RHF values with parent state
  useEffect(() => {
    const subscription = methods.watch((values) => {
      if (values.allocationTime)
        setAllocationTime(values.allocationTime.toISOString());
      if (values.campaignPickTime)
        setCampaignPickTime(values.campaignPickTime.toISOString());
      if (values.internalPublishedTime)
        setInternalPublishedTime(values.internalPublishedTime.toISOString());
    });
    return () => subscription.unsubscribe();
  }, [
    methods,
    setAllocationTime,
    setCampaignPickTime,
    setInternalPublishedTime,
  ]);

  // Calculate TAT & Completion Time
  useEffect(() => {
    if (allocationTime && internalPublishedTime) {
      const diff = new Date(internalPublishedTime) - new Date(allocationTime);
      if (!isNaN(diff)) {
        const mins = Math.floor(diff / 60000);
        const hours = Math.floor(mins / 60);
        setTAT(`${hours}h ${mins % 60}m`);
      }
    }
    if (campaignPickTime && internalPublishedTime) {
      const diff = new Date(internalPublishedTime) - new Date(campaignPickTime);
      if (!isNaN(diff)) {
        const mins = Math.floor(diff / 60000);
        const hours = Math.floor(mins / 60);
        setCompletionTime(`${hours}h ${mins % 60}m`);
      }
    }
  }, [allocationTime, campaignPickTime, internalPublishedTime]);

  const stripHtmlTags = (html) => {
    const div = document.createElement("div");
    div.innerHTML = html;
    return div.textContent || div.innerText || "";
  };

  const validate = () => {
    const newErrors = {};
    const plainDescription = stripHtmlTags(description).trim();

    if (!plainDescription) newErrors.description = "Description is required";
    if (userRoles !== "Tester") {
      if (!allocationTime) newErrors.allocationTime = "Time required";
      if (!campaignPickTime) newErrors.campaignPickTime = "Time required";
      if (!internalPublishedTime)
        newErrors.internalPublishedTime = "Time required";
    }

    // ✅ Only validate additional link if visible
    if (
      userRoles !== "Tester" &&
      showAdditionalLink &&
      !additionalLink.trim()
    ) {
      newErrors.additionalLink = "Additional Link is required";
    }

    return newErrors;
  };

  const handleSubmit = () => {
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // sanitize before saving
    const safeDescription = DOMPurify.sanitize(description);
    setDescription(safeDescription);
    onSubmit();
  };

  return (
    <FormProvider {...methods}>
      <div className="mb-3 flex justify-end">
        <Button
          label="Update on a specific Asset"
          icon="pi pi-plus"
          className="p-button-warning p-button-sm text-xs px-2 py-1"
          onClick={() => setUpdateOnAsset(true)}
        />
      </div>

      <div className="mb-3">
        <label className="font-semibold block mb-1">Campaign Name</label>
        <InputText
          value={selectedCampaign.Campaign_Name}
          disabled
          className="w-full nametest"
        />
      </div>

      <div className="mb-3">
        <label className="font-semibold block mb-1">Description *</label>
        <Editor
          value={description}
          onTextChange={(e) => {
            setDescription(e.htmlValue);
            if (errors.description) setErrors({ ...errors, description: "" });
          }}
          style={{ height: "160px" }}
          className="w-full"
        />
        {errors.description && (
          <small className="p-error">{errors.description}</small>
        )}
      </div>
      {userRoles !== "Tester" && (
        <div className="mb-3 flex items-center gap-3">
          <label className="font-semibold">Add Additional Link</label>
          <InputSwitch
            checked={showAdditionalLink}
            onChange={(e) => {
              setShowAdditionalLink(e.value);
              if (!e.value) setErrors({ ...errors, additionalLink: "" });
            }}
          />
        </div>
      )}

      {showAdditionalLink && (
        <div className="mb-3 relative">
          <label className="font-semibold block mb-1">
            Paste Excel Table *
          </label>
          <InputTextarea
            value={additionalLink}
            onChange={(e) => {
              setAdditionalLink(e.target.value);
              if (errors.additionalLink)
                setErrors({ ...errors, additionalLink: "" });
            }}
            rows={3}
            className="w-full"
            style={{
              backgroundColor: "transparent",
              color: additionalLink ? "#000" : "transparent",
              zIndex: 2,
              position: "relative",
            }}
          />
          {!additionalLink && (
            <img
              src="/Excel-Placeholder.jpg"
              alt="Excel Placeholder"
              style={{
                position: "absolute",
                top: "34px",
                left: "10px",
                right: "10px",
                height: "55%",
                width: "95%",
                opacity: 0.6,
                pointerEvents: "none",
                objectFit: "contain",
                zIndex: 1,
              }}
            />
          )}
          {errors.additionalLink && (
            <small className="p-error">{errors.additionalLink}</small>
          )}
        </div>
      )}
      {userRoles !== "Tester" && (
        <div className="field row">
          {/* Allocation Time */}
          <div className="field col-3">
            <label className="font-semibold block mb-1">
              Allocation Time *
            </label>
            <DateTimeInput name="allocationTime" />
            {errors.allocationTime && (
              <small className="p-error">{errors.allocationTime}</small>
            )}
          </div>

          {/* Campaign Pick Time */}
          <div className="field col-3">
            <label className="font-semibold block mb-1">
              Campaign Pick Time *
            </label>
            <DateTimeInput name="campaignPickTime" />
            {errors.campaignPickTime && (
              <small className="p-error">{errors.campaignPickTime}</small>
            )}
          </div>

          {/* Internal Published Time */}
          <div className="field col-3">
            <label className="font-semibold block mb-1">
              Internal Published Time *
            </label>
            <DateTimeInput name="internalPublishedTime" />
            {errors.internalPublishedTime && (
              <small className="p-error">{errors.internalPublishedTime}</small>
            )}
          </div>

          {/* TAT / CT */}
          <div className="field col-3">
            <label className="font-semibold block mb-1">TAT / CT</label>
            <InputText
              className="pinput w-full"
              value={`${tat} / ${completionTime}`}
              disabled
            />
          </div>
        </div>
      )}
      <Button
        label="Submit Update"
        className="p-button-success"
        onClick={handleSubmit}
      />
    </FormProvider>
  );
};

export default UpdateForm;
