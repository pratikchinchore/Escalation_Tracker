import { useContext, useEffect, useState } from "react";
import { InputText } from "primereact/inputtext";
import { InputTextarea } from "primereact/inputtextarea";
import { InputSwitch } from "primereact/inputswitch";
import { Button } from "primereact/button";
import { Editor } from "primereact/editor";
import { useForm, FormProvider, Controller } from "react-hook-form";
import "./styles.css";
import DateTimeInput from "./DateTIme/DateTimeInput";
import DOMPurify from "dompurify";
import api from "../../axiosConfig";
import { AuthContext } from "../../contexts/AuthContext";

const UpdateForm = ({
  selectedCampaign,
  description,
  allocationTime,
  campaignPickTime,
  internalPublishedTime,
  showAdditionalLink,
  additionalLink,
  setDescription,
  setAllocationTime,
  setCampaignPickTime,
  setInternalPublishedTime,
  setShowAdditionalLink,
  setAdditionalLink,
  onSubmit,
  updateOnAsset,
  setUpdateOnAsset,
  mode,
}) => {
  const [tat, setTAT] = useState("");
  const [completionTime, setCompletionTime] = useState("");
    const { auth } = useContext(AuthContext);
    const userRoles = auth?.decoded?.role;
  // const userRoles = localStorage.getItem("role");

  const isUpdate = mode === "update";

  // ✅ react-hook-form context
  const methods = useForm({
    defaultValues: {
      allocationTime: allocationTime ? new Date(allocationTime) : null,
      campaignPickTime: campaignPickTime ? new Date(campaignPickTime) : null,
      internalPublishedTime: internalPublishedTime
        ? new Date(internalPublishedTime)
        : null,
      Campaign_Name: selectedCampaign?.Campaign_Name || "",
      description: description || "",
      additionalLink: additionalLink || "",
    },
  });

  // ✅ Sync RHF values with parent state
  useEffect(() => {
    const subscription = methods.watch((values) => {
      if (values.allocationTime)
        setAllocationTime(values.allocationTime?.toISOString());
      if (values.campaignPickTime)
        setCampaignPickTime(values.campaignPickTime?.toISOString());
      if (values.internalPublishedTime)
        setInternalPublishedTime(values.internalPublishedTime?.toISOString());
      setDescription(values.description || "");
      setAdditionalLink(values.additionalLink || "");
    });
    return () => subscription.unsubscribe();
  }, [
    methods,
    setAllocationTime,
    setCampaignPickTime,
    setInternalPublishedTime,
    setDescription,
    setAdditionalLink,
  ]);

  // Calculate TAT & Completion Time
  useEffect(() => {
    if (allocationTime && internalPublishedTime) {
      const diff = new Date(internalPublishedTime) - new Date(allocationTime);
      if (!isNaN(diff)) {
        const mins = Math.floor(diff / 60000);
        const hours = Math.floor(mins / 60);
        setTAT(`${hours}h ${mins % 60}m`);
      }
    }
    if (campaignPickTime && internalPublishedTime) {
      const diff = new Date(internalPublishedTime) - new Date(campaignPickTime);
      if (!isNaN(diff)) {
        const mins = Math.floor(diff / 60000);
        const hours = Math.floor(mins / 60);
        setCompletionTime(`${hours}h ${mins % 60}m`);
      }
    }
  }, [allocationTime, campaignPickTime, internalPublishedTime]);

  const handleSubmit1 = async (values) => {
    //console.log("✅ Submitted values:", values);

    const safeDescription = DOMPurify.sanitize(values.description);

    try {
      if (isUpdate) {
        await api.put(`/updates/${selectedCampaign.id}`, {
          description: safeDescription,
          allocationTime: values.allocationTime,
          campaignPickTime: values.campaignPickTime,
          internalPublishedTime: values.internalPublishedTime,
          TAT: tat,
          CT: completionTime,
        });
      } else {
        await api.post(`/updates`, {
          camp_id: selectedCampaign.camp_id,
          description: safeDescription,
          allocationTime: values.allocationTime,
          campaignPickTime: values.campaignPickTime,
          internalPublishedTime: values.internalPublishedTime,
          TAT: tat,
          CT: completionTime,
        });
      }

      // ✅ Reset the form after successful submit
      methods.reset({
        allocationTime: null,
        campaignPickTime: null,
        internalPublishedTime: null,
        Campaign_Name: selectedCampaign?.Campaign_Name || "",
        description: "",
        additionalLink: "",
      });

      // ✅ Also clear parent states
      setDescription("");
      setAllocationTime(null);
      setCampaignPickTime(null);
      setInternalPublishedTime(null);
      setShowAdditionalLink(false);
      setAdditionalLink("");
      setUpdateOnAsset(false);
      setTAT("");
      setCompletionTime("");

      onSubmit(); // keep your existing callback
    } catch (err) {
      console.error("Error saving update", err);
    }
  };

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(handleSubmit1)}>
        <div className="mb-3 flex justify-end">
          <Button
            label="Update on a specific Asset"
            icon="pi pi-plus"
            className="p-button-warning p-button-sm text-xs px-2 py-1"
            onClick={() => setUpdateOnAsset(true)}
          />
        </div>

        {/* Campaign Name */}
        <div className="mb-3">
          <label className="font-semibold block mb-1">Campaign Name *</label>
          <Controller
            name="Campaign_Name"
            control={methods.control}
            rules={{ required: "Campaign Name is required" }}
            render={({ field, fieldState }) => (
              <>
                <InputText {...field} disabled className="w-full nametest" />
                {fieldState.error && (
                  <small className="p-error">{fieldState.error.message}</small>
                )}
              </>
            )}
          />
        </div>

        {/* Description */}
        <div className="mb-3">
          <label className="font-semibold block mb-1">Description *</label>
          <Controller
            name="description"
            control={methods.control}
            rules={{ required: "Description is required" }}
            render={({ field, fieldState }) => (
              <>
                <Editor
                  value={field.value}
                  onTextChange={(e) => field.onChange(e.htmlValue)}
                  style={{ height: "160px" }}
                  className={`w-full ${isUpdate ? "nametest" : ""}`}
                  readOnly={isUpdate}
                  showHeader={!isUpdate}
                />
                {fieldState.error && (
                  <small className="p-error">{fieldState.error.message}</small>
                )}
              </>
            )}
          />
        </div>

        {userRoles !== "Tester" && (
          <div className="mb-3 flex items-center gap-3">
            <label className="font-semibold">Add Additional Link</label>
            <InputSwitch
              checked={showAdditionalLink}
              onChange={(e) => setShowAdditionalLink(e.value)}
            />
          </div>
        )}

        {showAdditionalLink && (
          <div className="mb-3 relative">
            <label className="font-semibold block mb-1">
              Paste Excel Table *
            </label>
            <Controller
              name="additionalLink"
              control={methods.control}
              rules={{
                required: showAdditionalLink
                  ? "Additional Link is required"
                  : false,
              }}
              render={({ field, fieldState }) => (
                <>
                  <InputTextarea {...field} rows={3} className="w-full" />
                  {fieldState.error && (
                    <small className="p-error">
                      {fieldState.error.message}
                    </small>
                  )}
                </>
              )}
            />
          </div>
        )}

        {userRoles !== "Tester" && (
          <div className="field row">
            {/* Allocation Time */}
            <div className="field col-3">
              <label className="font-semibold block mb-1">
                Allocation Time *
              </label>
              <DateTimeInput
                name="allocationTime"
                control={methods.control}
                errors={methods.formState.errors}
                rules={{ required: "Allocation Time is required" }}
              />
            </div>

            {/* Campaign Pick Time */}
            <div className="field col-3">
              <label className="font-semibold block mb-1">
                Campaign Pick Time *
              </label>
              <DateTimeInput
                name="campaignPickTime"
                control={methods.control}
                errors={methods.formState.errors}
                rules={{ required: "Campaign Pick Time is required" }}
              />
            </div>

            {/* Internal Published Time */}
            <div className="field col-3">
              <label className="font-semibold block mb-1">
                Internal Published Time *
              </label>
              <DateTimeInput
                name="internalPublishedTime"
                control={methods.control}
                errors={methods.formState.errors}
                rules={{ required: "Internal Published Time is required" }}
              />
            </div>

            {/* TAT / CT */}
            <div className="field col-3">
              <label className="font-semibold block mb-1">TAT / CT</label>
              <InputText
                className="pinput w-full"
                value={`${tat} / ${completionTime}`}
                disabled
              />
            </div>
          </div>
        )}

        <Button
          label="Submit Update"
          className="p-button-success"
          type="submit"
        />
      </form>
    </FormProvider>
  );
};

export default UpdateForm;
