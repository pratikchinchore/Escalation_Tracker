import React, { useEffect, useState, useRef, useContext } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Paginator } from "primereact/paginator";
import { Toast } from "primereact/toast";
import api from "../../axiosConfig";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog"; // 👈 import Dialog
import "./styles.css";
import DOMPurify from "dompurify";
import UpdateForm from "./UpdateForm";
import { AuthContext } from "../../contexts/AuthContext";

const UpdatesTable = ({ campaignId,selectedCampaign, onPendingCountChange }) => {
  const [updates, setUpdates] = useState([]);
  const [totalUpdates, setTotalUpdates] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(5);
  const [loadingUpdateId, setLoadingUpdateId] = useState(null);
  const [selectedDescription, setSelectedDescription] = useState(null);
  const [selectedUpdate, setSelectedUpdate] = useState(null); // 🔹 open in dialog
  const toast = useRef(null);
  const { auth } = useContext(AuthContext);
      const userRoles = auth?.decoded?.role;

  const formatDateTime = (value) => {
    if (!value) return "";
    const date = new Date(value);
    return date.toLocaleString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const fetchUpdates = async (page = 1) => {

   // console.log("selectedCampaign------------",selectedCampaign);
    
    try {
      const res = await api.get(`/updates`, {
        params: { campaignId, page, limit: rows, searchTerm },
      });

      setUpdates(res.data.updates || []);
      setTotalUpdates(res.data.total || 0);

      const pendingCount = res.data.pendingCount ?? 0;
      if (onPendingCountChange) {
        onPendingCountChange(campaignId, pendingCount);
      }
    } catch (err) {
      console.error("Failed to load updates", err);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to fetch updates",
        life: 3000,
      });
    }
  };

  useEffect(() => {
    fetchUpdates(first / rows + 1);
  }, [first, rows, searchTerm]);

  const handleStatusToggle = async (updateId, currentStatus) => {
    const newStatus =
      currentStatus === "Done"
        ? "Pending"
        : currentStatus === "Internal-Update"
        ? "Pending"
        : "Done";

    try {
      setLoadingUpdateId(updateId);
      await api.put(`/updates/${updateId}/status`, { status: newStatus });

      setUpdates((prev) =>
        prev.map((update) =>
          update.id === updateId
            ? { ...update, testing_status: newStatus }
            : update
        )
      );

      if (onPendingCountChange) {
        onPendingCountChange(campaignId);
      }

      toast.current?.show({
        severity: "success",
        summary: "Status Updated",
        detail: `Testing status set to "${newStatus}"`,
        life: 3000,
      });
    } catch (err) {
      console.error("Failed to update status", err);
      toast.current?.show({
        severity: "error",
        summary: "Update Failed",
        detail: "Could not update testing status",
        life: 3000,
      });
    } finally {
      setLoadingUpdateId(null);
    }
  };

  const statusBodyTemplate = (rowData) => {
    const isLoading = loadingUpdateId === rowData.id;
    const status = rowData.testing_status || "Pending";
    const isDone = status === "Done";
    const isInternalUpdate = status === "Internal-Update";

    return (
      <div className="flex items-center gap-3">
        {isDone ? (
          <Button
            label="Done"
            icon="pi pi-check"
            className="custom-status-button done-status"
            disabled
          />
        ) : isInternalUpdate ? (
          <Button
            label="Internal Update"
            icon="pi pi-refresh"
            className="custom-status-button internal-update-status"
            onClick={() => { console.log("🙌🙌",rowData);
             setSelectedUpdate({...selectedCampaign ,...rowData}) } } // 👈 open dialog
            disabled={isLoading}
          />
        ) : userRoles?.includes("Tester") ? (
          <Button
            label="Mark as Done"
            icon="pi pi-play"
            className="custom-status-button pending-status"
            onClick={() =>
              handleStatusToggle(rowData.id, rowData.testing_status)
            }
            disabled={isLoading}
          />
        ) : (
          <Button
            label="Pending"
            icon="pi pi-clock"
            className="custom-status-button pending-status"
            disabled
          />
        )}
      </div>
    );
  };

  const descriptionBodyTemplate = (rowData) => {
    const plainText = DOMPurify.sanitize(rowData.description, {
      ALLOWED_TAGS: [],
    });
    const preview =
      plainText.length > 40 ? plainText.substring(0, 40) + "..." : plainText;

    return (
      <span
        className="description-preview text-primary cursor-pointer"
        onClick={() => setSelectedDescription(rowData.description)}
      >
        {preview}
      </span>
    );
  };

  return (
    <div>
      <Toast ref={toast} />

      {/* 🔹 UpdateForm in Dialog */}
      <Dialog
        header="Update"
        visible={!!selectedUpdate}
        style={{ width: "80vw" }}
        modal
        onHide={() => setSelectedUpdate(null)}
      >
        {selectedUpdate && (
          <UpdateForm
            selectedCampaign={selectedUpdate}
           
            description={selectedUpdate?.description || ""}
            allocationTime={selectedUpdate?.allocationTime || null}
            campaignPickTime={selectedUpdate?.campaignPickTime || null}
            internalPublishedTime={
              selectedUpdate?.internalPublishedTime || null
            }
            showAdditionalLink={!!selectedUpdate?.additionalLink}
            additionalLink={selectedUpdate?.additionalLink || ""}
            setDescription={() => {}}
            setAllocationTime={() => {}}
            setCampaignPickTime={() => {}}
            setInternalPublishedTime={() => {}}
            setShowAdditionalLink={() => {}}
            setAdditionalLink={() => {}}
            updateOnAsset={false}
            setUpdateOnAsset={() => {}}
            mode={
              selectedUpdate?.testing_status === "Internal-Update"
                ? "update"
                : "create"
            } // 👈 pass mode
            onSubmit={() => {
              setSelectedUpdate(null);
              fetchUpdates(first / rows + 1);
            }}
          />
        )}
      </Dialog>

      {/* Table */}
      <DataTable
        value={[...updates]
          .reverse()
          .filter((row) =>
            Object.values(row).some((val) =>
              val?.toString().toLowerCase().includes(searchTerm.toLowerCase())
            )
          )}
        responsiveLayout="stack" // ✅ stack columns instead of scroll
        style={{ width: "100%" }} // ✅ full width
        stripedRows
      >
        <Column
          field="description"
          header="Description"
          body={descriptionBodyTemplate}
        />

        {userRoles?.includes("Admin") && (
          <Column
            field="allocationTime"
            header="Allocation Time"
            body={(rowData) => formatDateTime(rowData.allocationTime)}
          />
        )}

        {userRoles?.includes("Admin") && (
          <Column
            field="internalPublishedTime"
            header="Published Time"
            body={(rowData) => formatDateTime(rowData.internalPublishedTime)}
          />
        )}

        <Column field="made_by" header="Made By" />
        <Column field="update_type" header="Update Type" />
        <Column header="Testing Status" body={statusBodyTemplate} />
      </DataTable>

      <Paginator
        first={first}
        rows={rows}
        totalRecords={totalUpdates}
        rowsPerPageOptions={[5, 10, 20]}
        onPageChange={(e) => {
          setFirst(e.first);
          setRows(e.rows);
        }}
        className="mt-3"
      />
    </div>
  );
};

export default UpdatesTable;
