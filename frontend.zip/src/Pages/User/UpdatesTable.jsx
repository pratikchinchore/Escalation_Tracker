import React, { useEffect, useState, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Paginator } from "primereact/paginator";
import { Toast } from "primereact/toast";
import { Dialog } from "primereact/dialog";
import api from "../../axiosConfig";
import { Button } from "primereact/button";
import "./styles.css";
import DOMPurify from "dompurify";

const UpdatesTable = ({ campaignId, onPendingCountChange }) => {
  const [updates, setUpdates] = useState([]);
  const [totalUpdates, setTotalUpdates] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [first, setFirst] = useState(0);
  const [rows, setRows] = useState(5);
  const [loadingUpdateId, setLoadingUpdateId] = useState(null);
  const [selectedDescription, setSelectedDescription] = useState(null);
  const toast = useRef(null);
  const userRoles = localStorage.getItem("role");

  const formatDateTime = (value) => {
    if (!value) return "";
    const date = new Date(value);
    return date.toLocaleString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const fetchUpdates = async (page = 1) => {
    try {
      const res = await api.get(`/updates`, {
        params: {
          campaignId,
          page,
          limit: rows,
          searchTerm,
        },
      });

      setUpdates(res.data.updates);
      setTotalUpdates(res.data.total);

      // 🔹 Use backend-provided pending count (across all campaigns/updates)
      const pendingCount = res.data.pendingCount ?? 0;

      // 🔹 Inform parent with total pending count
      if (onPendingCountChange) {
        onPendingCountChange(campaignId, pendingCount); // ✅ campaignId + count
      }
    } catch (err) {
      console.error("Failed to load updates", err);
      toast.current?.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to fetch updates",
        life: 3000,
      });
    }
  };

  useEffect(() => {
    fetchUpdates(first / rows + 1);
  }, [first, rows, searchTerm]);

  const handleStatusToggle = async (updateId, currentStatus) => {
    const newStatus = currentStatus === "Done" ? "Pending" : "Done";

    try {
      setLoadingUpdateId(updateId);
      await api.put(`/updates/${updateId}/status`, { status: newStatus });

      setUpdates((prev) => {
        const updated = prev.map((update) =>
          update.id === updateId
            ? { ...update, testing_status: newStatus }
            : update
        );

        const newPending = updated.filter(
          (u) => u.testing_status !== "Done"
        ).length;

        return updated;
      });

      if (onPendingCountChange) {
        onPendingCountChange(campaignId);
      }

      toast.current?.show({
        severity: "success",
        summary: "Status Updated",
        detail: `Testing status set to "${newStatus}"`,
        life: 3000,
      });
    } catch (err) {
      console.error("Failed to update status", err);
      toast.current?.show({
        severity: "error",
        summary: "Update Failed",
        detail: "Could not update testing status",
        life: 3000,
      });
    } finally {
      setLoadingUpdateId(null);
    }
  };

  const statusBodyTemplate = (rowData) => {
    const isLoading = loadingUpdateId === rowData.id;
    const status = rowData.testing_status || "Pending";
    const isDone = status === "Done";

    return (
      <div className="flex items-center gap-3">
        {isDone ? (
          <Button
            label="Done"
            icon="pi pi-check"
            className="custom-status-button done-status"
            disabled
          />
        ) : userRoles.includes("Tester") ? (
          <Button
            label="Mark as Done"
            icon="pi pi-play"
            className="custom-status-button pending-status"
            onClick={() =>
              handleStatusToggle(rowData.id, rowData.testing_status)
            }
            disabled={isLoading}
          />
        ) : (
          <Button
            label="Pending"
            icon="pi pi-clock"
            className="custom-status-button pending-status"
            disabled
          />
        )}
      </div>
    );
  };

  const descriptionBodyTemplate = (rowData) => {
    const plainText = DOMPurify.sanitize(rowData.description, {
      ALLOWED_TAGS: [],
    });
    const preview =
      plainText.length > 40 ? plainText.substring(0, 40) + "..." : plainText;

    return (
      <span
        className="description-preview text-primary cursor-pointer"
        onClick={() => setSelectedDescription(rowData.description)}
      >
        {preview}
      </span>
    );
  };
  return (
    <div>
      <Toast ref={toast} />

      <DataTable value={updates} responsiveLayout="scroll">
        <Column
          field="description"
          header="Description"
          body={descriptionBodyTemplate}
        />

        {userRoles?.includes("Admin") && (
          <Column
            field="allocationTime"
            header="Allocation Time"
            body={(rowData) => formatDateTime(rowData.allocationTime)}
          />
        )}

        {userRoles?.includes("Admin") && (
          <Column
            field="internalPublishedTime"
            header="Published Time"
            body={(rowData) => formatDateTime(rowData.internalPublishedTime)}
          />
        )}
        <Column field="made_by" header="Made By" />
        <Column field="update_type" header="Update Type" />
        <Column header="Testing Status" body={statusBodyTemplate} />
      </DataTable>

      <Dialog
        header="Full Update Description"
        visible={!!selectedDescription}
        style={{ width: "50vw" }}
        onHide={() => setSelectedDescription(null)}
        modal
      >
        <div
          dangerouslySetInnerHTML={{
            __html: DOMPurify.sanitize(selectedDescription),
          }}
        />
      </Dialog>

      <Paginator
        first={first}
        rows={rows}
        totalRecords={totalUpdates}
        rowsPerPageOptions={[5, 10, 20]}
        onPageChange={(e) => {
          setFirst(e.first);
          setRows(e.rows);
        }}
        className="mt-3"
      />
    </div>
  );
};

export default UpdatesTable;
