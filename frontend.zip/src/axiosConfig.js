import axios from "axios";

const api = axios.create({
  baseURL: "http://192.168.16.253:5000/api",
});

// api.interceptors.request.use((config) => {
//   const auth = localStorage.getItem("auth");
//   if (auth) {
//     const { token } = auth;
//     if (token) {
//       config.headers.Authorization = `Bearer ${token}`;
//     }
//   }
//   return config;
// });


api.interceptors.request.use((config) => {
  const token = localStorage.getItem("auth");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 421) {
      // Dispatch global event
      window.dispatchEvent(new Event("sessionExpired"));
    }
    return Promise.reject(error);
  }
);

export default api;
