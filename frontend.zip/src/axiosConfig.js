import axios from "axios";

const api = axios.create({
  baseURL: "http://192.168.16.253:5000/api",
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Expired or invalid token handler
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && (error.response.status === 403)) {
    // if (error.response && (error.response.status === 401 || error.response.status === 403)) {
      alert("Session expired. Please login again.");
      localStorage.removeItem("token");
      localStorage.removeItem("role");
      localStorage.removeItem("username");
      window.location.href = "/Signup";
    }
    return Promise.reject(error);
  }
);

export default api;
