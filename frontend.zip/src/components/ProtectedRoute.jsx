// src/components/ProtectedRoute.jsx
import React, { useContext } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { AuthContext } from '../contexts/AuthContext';

export const ProtectedRoute = ({ requiredRole }) => {
  const { auth } = useContext(AuthContext);
 

  if (!auth.user) {
    // Not logged in
    return <Navigate to="/login" replace />;
  }

  if (requiredRole && auth.user.role !== requiredRole) {
    // Logged in but wrong role
    return <Navigate to="/not-authorized" replace />;
  }

  // OK: render nested routes
  return <Outlet />;
};
