// src/components/SessionExpiredModal.jsx
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";

export default function SessionExpiredModal({ visible, onConfirm }) {
  return (
    <Dialog
      header="⚠️ Session Expired"
      visible={visible}
      style={{ width: "400px" }}
      closable={false}
      modal
    >
      <p className="m-0">
        Your session has expired. Please login again to continue.
      </p>
      <div className="flex justify-end gap-2 mt-4">
        <Button
          label="OK"
          icon="pi pi-check"
          className="p-button-danger"
          onClick={onConfirm}
        />
      </div>
    </Dialog>
  );
}
