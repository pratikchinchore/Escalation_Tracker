import { createContext, useState, useEffect } from "react";
import axios from "axios";
import { jwtDecode } from "jwt-decode";

import SessionExpiredModal from "../components/SessionExpiredModal";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState(() => {
    const saved = localStorage.getItem("auth");
    return saved ? JSON.parse(saved) : { user: null, token: null };
  });

  const [sessionExpired, setSessionExpired] = useState(false);

  useEffect(() => {
    if (auth.token) {
      axios.defaults.headers.common["Authorization"] = `Bearer ${auth.token}`;

      try {
        const decoded = jwtDecode(auth.token);
        const expiry = decoded.exp * 1000;
        const now = Date.now();
        const timeout = expiry - now;

        if (timeout > 0) {
          const timer = setTimeout(() => {
            setSessionExpired(true);
          }, timeout);

          return () => clearTimeout(timer);
        } else {
          setSessionExpired(true);
        }
      } catch (e) {
        console.error("Token decode failed", e);
        setSessionExpired(true);
      }
    }
  }, [auth.token]);

  // 👇 listen for server-side expired token
  useEffect(() => {
    const handler = () => setSessionExpired(true);
    window.addEventListener("sessionExpired", handler);
    return () => window.removeEventListener("sessionExpired", handler);
  }, []);

  const login = async (username, password) => {
    const response = await axios.post("/api/auth/login", { username, password });
    const { token, user } = response.data;
    const authData = { user, token };
    setAuth(authData);
    localStorage.setItem("auth", JSON.stringify(authData));
    axios.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  };

  const logout = () => {
    setAuth({ user: null, token: null });
    localStorage.removeItem("auth");
    delete axios.defaults.headers.common["Authorization"];
  };

  const handleSessionExpiredConfirm = () => {
    logout();
    setSessionExpired(false);
    window.location.href = "/Signup";
  };

  return (
    <AuthContext.Provider value={{ auth, login, logout }}>
      {children}
      <SessionExpiredModal
        visible={sessionExpired}
        onConfirm={handleSessionExpiredConfirm}
      />
    </AuthContext.Provider>
  );
};
