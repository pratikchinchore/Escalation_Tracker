// src/contexts/AuthContext.js
import { createContext, useState, useEffect } from "react";
import axios from "axios";
import { jwtDecode } from "jwt-decode";
import SessionExpiredModal from "../components/SessionExpiredModal";
import api from "../axiosConfig";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  // ✅ read token from localStorage on init
  const [auth, setAuth] = useState(() => {
    const token = localStorage.getItem("auth");
    if (!token) return null;

    try {
      const decoded = jwtDecode(token);
      return { token, decoded };
    } catch (err) {
      console.error("Invalid token in localStorage", err);
      return null;
    }
  });

  const [sessionExpired, setSessionExpired] = useState(false);

  // ✅ set axios header + expiry timer
  useEffect(() => {
    if (!auth?.token) return;

    axios.defaults.headers.common["Authorization"] = `Bearer ${auth.token}`;

    const expiry = auth.decoded.exp * 1000;
    const now = Date.now();
    const timeout = expiry - now;

    if (timeout <= 0) {
      setSessionExpired(true);
      return;
    }

    const timer = setTimeout(() => setSessionExpired(true), timeout);

    return () => clearTimeout(timer);
  }, [auth]);

  // ✅ listen for server-side expired token (status 421)
  useEffect(() => {
    const handler = () => setSessionExpired(true);
    window.addEventListener("sessionExpired", handler);
    return () => window.removeEventListener("sessionExpired", handler);
  }, []);

  // ✅ login
  const login = async (username, password) => {
    const response = await api.post("auth/login", { username, password });

    const { token, role, empID, isDefaultPassword } = response.data;

    localStorage.setItem("auth", token);

    const decoded = jwtDecode(token);
    setAuth({ token, decoded });

    return { token, role, empID, isDefaultPassword };
  };

  // ✅ logout
  const logout = () => {
    localStorage.clear();
    delete axios.defaults.headers.common["Authorization"];
    setAuth(null);
    window.location.href = "/Signup";
  };

  // ✅ confirm session expired → logout + redirect
  const handleSessionExpiredConfirm = () => {
    setSessionExpired(false);
    logout();
  };

  return (
    <AuthContext.Provider value={{ auth, login, logout }}>
      {children}
      <SessionExpiredModal
        visible={sessionExpired}
        onConfirm={handleSessionExpiredConfirm}
      />
    </AuthContext.Provider>
  );
};
